import { db } from "./db";
import { Channel, SyncStatus } from "@prisma/client";
import { decryptCredentials } from "./encryption";
import { ShopifyConnector } from "./connectors/shopify-connector";
import { EbayConnector } from "./connectors/ebay-connector";
import { AmazonConnector } from "./connectors/amazon-connector";

/**
 * Unified sync engine for managing product/inventory syncs across all channels
 */
export class SyncEngine {
  /**
   * Sync a product to a specific channel
   */
  static async syncProductToChannel(
    teamId: string,
    productId: string,
    channel: Channel,
    action: "create" | "update" | "delete" = "create"
  ) {
    // Create sync record
    const sync = await db.sync.create({
      data: {
        teamId,
        productId,
        channel,
        status: SyncStatus.IN_PROGRESS,
        startedAt: new Date(),
      },
    });

    try {
      // Get product data
      const product = await db.product.findUnique({
        where: { id: productId },
        include: {
          channelListings: {
            where: { channel },
          },
        },
      });

      if (!product) {
        throw new Error("Product not found");
      }

      // Get channel credentials
      const channelCreds = await db.channelCredentials.findUnique({
        where: {
          teamId_channel: { teamId, channel },
        },
      });

      if (!channelCreds || !channelCreds.isActive) {
        throw new Error(`${channel} credentials not configured`);
      }

      const credentials = decryptCredentials(
        channelCreds.credentialsEncrypted
      );

      // Get appropriate connector
      const connector = this.getConnector(channel, credentials);

      // Validate credentials
      const isValid = await connector.validateCredentials();
      if (!isValid) {
        throw new Error("Channel credentials are invalid or expired");
      }

      // Perform sync action
      let result;
      const existingListing = product.channelListings[0];

      if (action === "create" || !existingListing) {
        result = await connector.createProduct({
          id: product.id,
          title: product.name,
          description: product.description || "",
          price: product.price,
          currency: "USD",
          sku: product.sku,
          images: [],
          quantity: product.inventory,
        });

        if (result.success && result.externalId) {
          // Create or update listing record
          await db.productChannelListing.upsert({
            where: {
              productId_channel: { productId, channel },
            },
            update: {
              externalId: result.externalId,
              externalUrl: result.details?.externalUrl,
              lastSyncedAt: new Date(),
            },
            create: {
              productId,
              channel,
              externalId: result.externalId,
              externalUrl: result.details?.externalUrl,
              lastSyncedAt: new Date(),
            },
          });
        }
      } else if (action === "update" && existingListing) {
        result = await connector.updateProduct(existingListing.externalId, {
          title: product.name,
          description: product.description || "",
          price: product.price,
          quantity: product.inventory,
        });

        if (result.success) {
          await db.productChannelListing.update({
            where: { id: existingListing.id },
            data: { lastSyncedAt: new Date() },
          });
        }
      } else if (action === "delete" && existingListing) {
        result = await connector.deleteProduct(existingListing.externalId);

        if (result.success) {
          await db.productChannelListing.update({
            where: { id: existingListing.id },
            data: { status: "DELISTED" },
          });
        }
      }

      // Update sync record
      await db.sync.update({
        where: { id: sync.id },
        data: {
          status: result.success ? SyncStatus.SUCCESS : SyncStatus.FAILED,
          errorMessage: result.success ? null : result.message,
          completedAt: new Date(),
        },
      });

      // Log sync details
      await db.syncLog.create({
        data: {
          syncId: sync.id,
          message: result.message,
          level: result.success ? "INFO" : "ERROR",
        },
      });

      return { success: result.success, externalId: result.externalId };
    } catch (error) {
      const errorMsg =
        error instanceof Error ? error.message : "Unknown error";

      await db.sync.update({
        where: { id: sync.id },
        data: {
          status: SyncStatus.FAILED,
          errorMessage: errorMsg,
          completedAt: new Date(),
        },
      });

      await db.syncLog.create({
        data: {
          syncId: sync.id,
          message: errorMsg,
          level: "ERROR",
        },
      });

      throw error;
    }
  }

  /**
   * Sync inventory for a product across all active channels
   */
  static async syncInventoryToChannels(
    teamId: string,
    productId: string
  ) {
    const product = await db.product.findUnique({
      where: { id: productId },
      include: {
        channelListings: true,
      },
    });

    if (!product) {
      throw new Error("Product not found");
    }

    const results = [];

    for (const listing of product.channelListings) {
      if (listing.status === "DELISTED") {
        continue;
      }

      const sync = await db.sync.create({
        data: {
          teamId,
          productId,
          channel: listing.channel,
          status: SyncStatus.IN_PROGRESS,
          startedAt: new Date(),
        },
      });

      try {
        const channelCreds = await db.channelCredentials.findUnique({
          where: {
            teamId_channel: { teamId, channel: listing.channel },
          },
        });

        if (!channelCreds || !channelCreds.isActive) {
          throw new Error(`${listing.channel} credentials not configured`);
        }

        const credentials = decryptCredentials(
          channelCreds.credentialsEncrypted
        );
        const connector = this.getConnector(listing.channel, credentials);

        const result = await connector.syncInventory(
          listing.externalId,
          product.inventory
        );

        await db.sync.update({
          where: { id: sync.id },
          data: {
            status: result.success ? SyncStatus.SUCCESS : SyncStatus.FAILED,
            errorMessage: result.success ? null : result.message,
            completedAt: new Date(),
          },
        });

        await db.syncLog.create({
          data: {
            syncId: sync.id,
            message: result.message,
            level: result.success ? "INFO" : "ERROR",
          },
        });

        results.push({
          channel: listing.channel,
          success: result.success,
        });
      } catch (error) {
        const errorMsg =
          error instanceof Error ? error.message : "Unknown error";

        await db.sync.update({
          where: { id: sync.id },
          data: {
            status: SyncStatus.FAILED,
            errorMessage: errorMsg,
            completedAt: new Date(),
          },
        });

        await db.syncLog.create({
          data: {
            syncId: sync.id,
            message: errorMsg,
            level: "ERROR",
          },
        });

        results.push({
          channel: listing.channel,
          success: false,
        });
      }
    }

    return results;
  }

  /**
   * Get appropriate connector instance
   */
  private static getConnector(channel: Channel, credentials: any) {
    switch (channel) {
      case "SHOPIFY":
        return new ShopifyConnector(channel, credentials);
      case "EBAY":
        return new EbayConnector(channel, credentials);
      case "AMAZON":
        return new AmazonConnector(channel, credentials);
      default:
        throw new Error(`Unsupported channel: ${channel}`);
    }
  }
}
