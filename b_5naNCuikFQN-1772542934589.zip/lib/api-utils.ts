import { NextRequest, NextResponse } from 'next/server';

export class ApiError extends Error {
  constructor(
    public code: string,
    public statusCode: number,
    message: string
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export function errorResponse(error: unknown) {
  console.error('[API Error]', error);

  if (error instanceof ApiError) {
    return NextResponse.json(
      { error: error.message, code: error.code },
      { status: error.statusCode }
    );
  }

  if (error instanceof Error) {
    return NextResponse.json(
      { error: error.message, code: 'INTERNAL_ERROR' },
      { status: 500 }
    );
  }

  return NextResponse.json(
    { error: 'An unexpected error occurred', code: 'UNKNOWN_ERROR' },
    { status: 500 }
  );
}

export function successResponse<T>(data: T, statusCode: number = 200) {
  return NextResponse.json(data, { status: statusCode });
}

export async function validateRequest(
  request: NextRequest,
  schema: any
) {
  try {
    const body = await request.json();
    const validatedData = schema.parse(body);
    return { valid: true, data: validatedData, error: null };
  } catch (error) {
    if (error instanceof Error) {
      return { valid: false, data: null, error: error.message };
    }
    return { valid: false, data: null, error: 'Invalid request body' };
  }
}

export function verifyCronSecret(request: NextRequest): boolean {
  const authHeader = request.headers.get('authorization');
  const cronSecret = process.env.CRON_SECRET;

  if (!cronSecret) {
    console.error('CRON_SECRET not set');
    return false;
  }

  return authHeader === `Bearer ${cronSecret}`;
}

export function verifyWebhookSignature(
  payload: string,
  signature: string,
  secret: string
): boolean {
  const crypto = require('crypto');
  const hash = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  return hash === signature;
}

export async function withTeamContext(
  request: NextRequest,
  handler: (req: NextRequest, teamId: string) => Promise<NextResponse>
) {
  // This will be used with middleware to extract team context
  const teamId = request.headers.get('x-team-id');

  if (!teamId) {
    return NextResponse.json(
      { error: 'Team context not found' },
      { status: 401 }
    );
  }

  return handler(request, teamId);
}

export function getRetryWaitTime(retryCount: number): number {
  // Exponential backoff: 1s, 2s, 4s, 8s, 16s (max)
  return Math.min(1000 * Math.pow(2, retryCount), 16000);
}
