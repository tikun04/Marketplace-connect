import axios from 'axios';
import crypto from 'crypto';

export interface AmazonLwaCredentials {
  accessToken: string;
  refreshToken: string;
  expiresAt: number;
  region: string;
  marketplaceId: string;
}

/**
 * Amazon LWA (Login with Amazon) OAuth handler
 * Handles token exchange for SP-API authentication
 */
export class AmazonLWA {
  private clientId: string;
  private clientSecret: string;
  private refreshToken: string;

  constructor(refreshToken?: string) {
    this.clientId = process.env.AMAZON_CLIENT_ID || '';
    this.clientSecret = process.env.AMAZON_CLIENT_SECRET || '';
    this.refreshToken = refreshToken || process.env.AMAZON_REFRESH_TOKEN || '';

    if (!this.clientId || !this.clientSecret) {
      throw new Error('Missing required Amazon LWA environment variables');
    }
  }

  /**
   * Exchange refresh token for access token (LWA flow)
   */
  async getAccessToken(): Promise<AmazonLwaCredentials> {
    try {
      if (!this.refreshToken) {
        throw new Error('Refresh token required for Amazon authentication');
      }

      const response = await axios.post(
        'https://api.amazon.com/auth/o2/token',
        {
          grant_type: 'refresh_token',
          refresh_token: this.refreshToken,
          client_id: this.clientId,
          client_secret: this.clientSecret,
        },
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      );

      const { access_token, expires_in } = response.data;

      return {
        accessToken: access_token,
        refreshToken: this.refreshToken,
        expiresAt: Date.now() + (expires_in || 3599) * 1000,
        region: process.env.AMAZON_REGION || 'NA',
        marketplaceId: process.env.AMAZON_MARKETPLACE_ID || 'ATVPDKIKX0DER',
      };
    } catch (error) {
      console.error('Failed to get Amazon access token:', error);
      throw new Error('Failed to authenticate with Amazon LWA');
    }
  }

  /**
   * Check if access token needs refresh
   */
  needsRefresh(expiresAt: number, bufferMs: number = 300000): boolean {
    return Date.now() >= expiresAt - bufferMs;
  }

  /**
   * Format credentials for storage
   */
  formatCredentials(creds: AmazonLwaCredentials): Record<string, any> {
    return {
      refreshToken: creds.refreshToken,
      region: creds.region,
      marketplaceId: creds.marketplaceId,
      expiresAt: creds.expiresAt,
    };
  }
}

/**
 * Amazon SP-API request signer using AWS SigV4
 */
export class AmazonSPAPISigner {
  private accessKeyId: string;
  private secretAccessKey: string;
  private region: string;
  private service: string = 'execute-api';

  constructor() {
    this.accessKeyId = process.env.AWS_ACCESS_KEY_ID || '';
    this.secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY || '';
    this.region = process.env.AMAZON_REGION || 'us-east-1';

    if (!this.accessKeyId || !this.secretAccessKey) {
      throw new Error('Missing required AWS credentials for SP-API signing');
    }
  }

  /**
   * Create AWS SigV4 authorization headers for SP-API request
   */
  sign(
    method: string,
    host: string,
    path: string,
    payload?: string,
    spApiAccessToken?: string
  ): Record<string, string> {
    const timestamp = new Date().toISOString();
    const amzDate = timestamp.replace(/[-:.]|\.\d{3}/g, '').split('Z')[0] + 'Z';
    const datestamp = amzDate.substring(0, 8);

    // Canonical request
    const canonicalHeaders = `host:${host}\nx-amz-date:${amzDate}\n`;
    const signedHeaders = 'host;x-amz-date';

    const hashedPayload = this.hash(payload || '');
    const canonicalRequest =
      `${method}\n${path}\n\n` +
      `${canonicalHeaders}\n${signedHeaders}\n${hashedPayload}`;

    // String to sign
    const credentialScope = `${datestamp}/${this.region}/${this.service}/aws4_request`;
    const hashedCanonicalRequest = this.hash(canonicalRequest);
    const stringToSign =
      `AWS4-HMAC-SHA256\n${amzDate}\n${credentialScope}\n${hashedCanonicalRequest}`;

    // Calculate signature
    const kDate = this.hmac(
      `AWS4${this.secretAccessKey}`,
      datestamp
    );
    const kRegion = this.hmac(kDate, this.region);
    const kService = this.hmac(kRegion, this.service);
    const kSigning = this.hmac(kService, 'aws4_request');
    const signature = this.hmac(kSigning, stringToSign, 'hex');

    // Authorization header
    const authorizationHeader =
      `AWS4-HMAC-SHA256 Credential=${this.accessKeyId}/${credentialScope}, ` +
      `SignedHeaders=${signedHeaders}, Signature=${signature}`;

    return {
      'x-amz-date': amzDate,
      Authorization: authorizationHeader,
      ...(spApiAccessToken && { 'x-amz-access-token': spApiAccessToken }),
    };
  }

  private hash(data: string): string {
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  private hmac(
    key: string | Buffer,
    data: string,
    digest: 'hex' | 'binary' = 'binary'
  ): string | Buffer {
    return crypto.createHmac('sha256', key).update(data).digest(digest as any);
  }
}
