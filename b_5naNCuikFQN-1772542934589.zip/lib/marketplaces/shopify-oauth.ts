import axios from 'axios';
import { decryptCredentials, encryptCredentials } from '../encryption';

export interface ShopifyOAuthCredentials {
  accessToken: string;
  refreshToken?: string;
  scope: string;
  shop: string; // shop domain e.g. myshop.myshopify.com
  expiresAt?: number;
}

export class ShopifyOAuth {
  private clientId: string;
  private clientSecret: string;
  private redirectUri: string;

  constructor() {
    this.clientId = process.env.SHOPIFY_CLIENT_ID || '';
    this.clientSecret = process.env.SHOPIFY_CLIENT_SECRET || '';
    this.redirectUri = process.env.SHOPIFY_REDIRECT_URI || '';

    if (!this.clientId || !this.clientSecret || !this.redirectUri) {
      throw new Error('Missing required Shopify OAuth environment variables');
    }
  }

  /**
   * Generate authorization URL for Shopify OAuth flow
   */
  generateAuthUrl(shop: string, state: string, scopes: string[] = []): string {
    const defaultScopes = [
      'write_products',
      'read_products',
      'write_inventory',
      'read_inventory',
      'read_locations',
    ];

    const allScopes = scopes.length > 0 ? scopes : defaultScopes;
    const query = new URLSearchParams({
      client_id: this.clientId,
      scope: allScopes.join(','),
      redirect_uri: this.redirectUri,
      state,
    });

    return `https://${shop}.myshopify.com/admin/oauth/authorize?${query.toString()}`;
  }

  /**
   * Exchange authorization code for access token
   */
  async exchangeCodeForToken(
    shop: string,
    code: string
  ): Promise<ShopifyOAuthCredentials> {
    try {
      const response = await axios.post(
        `https://${shop}.myshopify.com/admin/oauth/access_token`,
        {
          client_id: this.clientId,
          client_secret: this.clientSecret,
          code,
        },
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );

      const { access_token, scope, expires_in } = response.data;

      // Shopify access tokens don't typically expire, but store expiry for tracking
      const expiresAt = expires_in ? Date.now() + expires_in * 1000 : undefined;

      return {
        accessToken: access_token,
        scope,
        shop,
        expiresAt,
      };
    } catch (error) {
      console.error('Failed to exchange Shopify auth code:', error);
      throw new Error('Failed to complete Shopify authentication');
    }
  }

  /**
   * Verify webhook signature from Shopify
   */
  verifyWebhookSignature(body: string, hmacHeader: string): boolean {
    try {
      const crypto = require('crypto');
      const hash = crypto
        .createHmac('sha256', this.clientSecret)
        .update(body, 'utf-8')
        .digest('base64');

      return hash === hmacHeader;
    } catch (error) {
      console.error('Failed to verify webhook signature:', error);
      return false;
    }
  }

  /**
   * Format credentials for storage
   */
  formatCredentials(creds: ShopifyOAuthCredentials): Record<string, any> {
    return {
      accessToken: creds.accessToken,
      shop: creds.shop,
      scope: creds.scope,
      expiresAt: creds.expiresAt,
    };
  }
}
