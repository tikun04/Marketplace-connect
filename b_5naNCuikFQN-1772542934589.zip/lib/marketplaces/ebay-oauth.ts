import axios from 'axios';

export interface EbayOAuthCredentials {
  accessToken: string;
  refreshToken: string;
  expiresAt: number; // Unix timestamp
  scope: string;
}

export class EbayOAuth {
  private clientId: string;
  private clientSecret: string;
  private redirectUri: string;
  private ruName: string;
  private sandboxMode: boolean;

  constructor(sandboxMode: boolean = false) {
    this.clientId = process.env.EBAY_CLIENT_ID || '';
    this.clientSecret = process.env.EBAY_CLIENT_SECRET || '';
    this.redirectUri = process.env.EBAY_REDIRECT_URI || '';
    this.ruName = process.env.EBAY_RU_NAME || '';
    this.sandboxMode = sandboxMode;

    if (!this.clientId || !this.clientSecret || !this.redirectUri || !this.ruName) {
      throw new Error('Missing required eBay OAuth environment variables');
    }
  }

  private getBaseUrl(): string {
    return this.sandboxMode ? 'https://sandbox.ebay.com' : 'https://signin.ebay.com';
  }

  private getApiUrl(): string {
    return this.sandboxMode
      ? 'https://api.sandbox.ebay.com'
      : 'https://api.ebay.com';
  }

  /**
   * Generate authorization URL for eBay OAuth flow
   */
  generateAuthUrl(state: string, scopes: string[] = []): string {
    const defaultScopes = [
      'https://api.ebay.com/oauth/api_scope',
      'https://api.ebay.com/oauth/api_scope/sell.inventory',
      'https://api.ebay.com/oauth/api_scope/sell.marketing',
    ];

    const allScopes = scopes.length > 0 ? scopes : defaultScopes;

    const query = new URLSearchParams({
      client_id: this.clientId,
      response_type: 'code',
      redirect_uri: this.redirectUri,
      scope: allScopes.join(' '),
      state,
      prompt: 'login',
    });

    return `${this.getBaseUrl()}/oauth2/authorize?${query.toString()}`;
  }

  /**
   * Exchange authorization code for tokens
   */
  async exchangeCodeForToken(code: string): Promise<EbayOAuthCredentials> {
    try {
      const auth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString(
        'base64'
      );

      const response = await axios.post(
        `${this.getApiUrl()}/identity/v1/oauth2/token`,
        new URLSearchParams({
          grant_type: 'authorization_code',
          code,
          redirect_uri: this.redirectUri,
        }),
        {
          headers: {
            Authorization: `Basic ${auth}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      );

      const { access_token, refresh_token, expires_in } = response.data;

      return {
        accessToken: access_token,
        refreshToken: refresh_token,
        expiresAt: Date.now() + (expires_in || 3600) * 1000,
        scope: 'https://api.ebay.com/oauth/api_scope',
      };
    } catch (error) {
      console.error('Failed to exchange eBay auth code:', error);
      throw new Error('Failed to complete eBay authentication');
    }
  }

  /**
   * Refresh an expired access token using refresh token
   */
  async refreshAccessToken(refreshToken: string): Promise<EbayOAuthCredentials> {
    try {
      const auth = Buffer.from(`${this.clientId}:${this.clientSecret}`).toString(
        'base64'
      );

      const response = await axios.post(
        `${this.getApiUrl()}/identity/v1/oauth2/token`,
        new URLSearchParams({
          grant_type: 'refresh_token',
          refresh_token: refreshToken,
          scope: 'https://api.ebay.com/oauth/api_scope',
        }),
        {
          headers: {
            Authorization: `Basic ${auth}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      );

      const { access_token, refresh_token, expires_in } = response.data;

      return {
        accessToken: access_token,
        refreshToken: refresh_token || refreshToken,
        expiresAt: Date.now() + (expires_in || 3600) * 1000,
        scope: 'https://api.ebay.com/oauth/api_scope',
      };
    } catch (error) {
      console.error('Failed to refresh eBay access token:', error);
      throw new Error('Failed to refresh eBay authentication');
    }
  }

  /**
   * Format credentials for storage
   */
  formatCredentials(creds: EbayOAuthCredentials): Record<string, any> {
    return {
      accessToken: creds.accessToken,
      refreshToken: creds.refreshToken,
      expiresAt: creds.expiresAt,
      scope: creds.scope,
      sandboxMode: this.sandboxMode,
    };
  }

  /**
   * Check if access token needs refresh
   */
  needsRefresh(expiresAt: number, bufferMs: number = 300000): boolean {
    return Date.now() >= expiresAt - bufferMs;
  }
}
