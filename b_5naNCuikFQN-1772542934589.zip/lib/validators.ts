import { z } from 'zod';

// Auth
export const signupSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  name: z.string().min(2, 'Name must be at least 2 characters'),
});

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string(),
});

// Team
export const createTeamSchema = z.object({
  name: z.string().min(1, 'Team name is required'),
  slug: z
    .string()
    .min(1, 'Slug is required')
    .regex(/^[a-z0-9-]+$/, 'Slug can only contain lowercase letters, numbers, and hyphens'),
});

export const inviteMemberSchema = z.object({
  email: z.string().email('Invalid email address'),
  role: z.enum(['OWNER', 'ADMIN', 'MEMBER']),
});

// Products
export const createProductSchema = z.object({
  sku: z.string().min(1, 'SKU is required'),
  name: z.string().min(1, 'Product name is required'),
  description: z.string().optional(),
  price: z.number().min(0, 'Price must be positive'),
  inventory: z.number().min(0, 'Inventory must be non-negative'),
  channels: z.array(z.enum(['AMAZON', 'SHOPIFY', 'EBAY'])).optional(),
});

export const updateProductSchema = createProductSchema.partial();

// Channels
export const connectChannelSchema = z.object({
  channel: z.enum(['AMAZON', 'SHOPIFY', 'EBAY']),
  credentials: z.record(z.any()),
});

export const disconnectChannelSchema = z.object({
  channel: z.enum(['AMAZON', 'SHOPIFY', 'EBAY']),
});

export const syncProductSchema = z.object({
  productId: z.string(),
  channels: z.array(z.enum(['AMAZON', 'SHOPIFY', 'EBAY'])),
});

// Types
export type SignupInput = z.infer<typeof signupSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type CreateTeamInput = z.infer<typeof createTeamSchema>;
export type InviteMemberInput = z.infer<typeof inviteMemberSchema>;
export type CreateProductInput = z.infer<typeof createProductSchema>;
export type UpdateProductInput = z.infer<typeof updateProductSchema>;
export type ConnectChannelInput = z.infer<typeof connectChannelSchema>;
export type SyncProductInput = z.infer<typeof syncProductSchema>;
