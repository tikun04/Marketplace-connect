import bcrypt from 'bcryptjs';
import { db } from './db';

const SALT_ROUNDS = 10;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function comparePasswords(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function createUser(email: string, name: string, passwordHash: string) {
  return db.user.create({
    data: {
      email,
      name,
      passwordHash,
    },
  });
}

export async function getUserByEmail(email: string) {
  return db.user.findUnique({
    where: { email },
  });
}

export async function createTeam(userId: string, name: string, slug: string) {
  // Create team and add user as owner
  const team = await db.team.create({
    data: {
      name,
      slug,
      members: {
        create: {
          userId,
          role: 'OWNER',
        },
      },
    },
    include: {
      members: true,
    },
  });

  return team;
}

export async function getUserTeams(userId: string) {
  return db.teamMember.findMany({
    where: { userId },
    include: {
      team: true,
    },
  });
}

export async function getTeamById(teamId: string) {
  return db.team.findUnique({
    where: { id: teamId },
    include: {
      members: {
        include: {
          user: {
            select: {
              id: true,
              email: true,
              name: true,
            },
          },
        },
      },
    },
  });
}

export async function getTeamBySlug(slug: string) {
  return db.team.findUnique({
    where: { slug },
  });
}

export async function isTeamMember(userId: string, teamId: string): Promise<boolean> {
  const member = await db.teamMember.findUnique({
    where: {
      userId_teamId: {
        userId,
        teamId,
      },
    },
  });

  return !!member;
}

export async function isTeamOwner(userId: string, teamId: string): Promise<boolean> {
  const member = await db.teamMember.findUnique({
    where: {
      userId_teamId: {
        userId,
        teamId,
      },
    },
  });

  return member?.role === 'OWNER';
}

export async function canUserAccessTeam(userId: string, teamId: string): Promise<boolean> {
  const member = await db.teamMember.findUnique({
    where: {
      userId_teamId: {
        userId,
        teamId,
      },
    },
  });

  return !!member;
}

export async function addTeamMember(
  teamId: string,
  email: string,
  role: 'OWNER' | 'ADMIN' | 'MEMBER'
) {
  const user = await getUserByEmail(email);

  if (!user) {
    throw new Error('User not found');
  }

  return db.teamMember.create({
    data: {
      userId: user.id,
      teamId,
      role,
    },
  });
}

export async function removeTeamMember(teamId: string, userId: string) {
  return db.teamMember.delete({
    where: {
      userId_teamId: {
        userId,
        teamId,
      },
    },
  });
}

export async function generateSessionToken(): Promise<string> {
  return require('crypto').randomBytes(32).toString('hex');
}
