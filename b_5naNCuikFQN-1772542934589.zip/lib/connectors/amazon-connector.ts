import {
  BaseConnector,
  ConnectorCredentials,
  ProductData,
  SyncResult,
  WebhookPayload,
} from "./base-connector";
import axios, { AxiosError } from "axios";
import { AmazonLWA, AmazonSPAPISigner } from "../marketplaces/amazon-lwa";

/**
 * Production Amazon SP-API Connector
 * Implements LWA token exchange, AWS SigV4 signing, and Listings Items API
 */
export class AmazonConnector extends BaseConnector {
  private lwaHandler: AmazonLWA;
  private signer: AmazonSPAPISigner;
  private accessToken?: string;
  private tokenExpiresAt?: number;

  constructor(channel: any, credentials: ConnectorCredentials) {
    super(channel, credentials);
    this.lwaHandler = new AmazonLWA(credentials.refreshToken as string);
    this.signer = new AmazonSPAPISigner();
  }

  private getBaseUrl(): string {
    const region = (this.credentials.region as string) || "NA";
    const regionMap: Record<string, string> = {
      NA: "https://sellingpartnerapi-na.amazon.com", // North America
      EU: "https://sellingpartnerapi-eu.amazon.com", // Europe
      FE: "https://sellingpartnerapi-fe.amazon.com", // Far East (Japan, Singapore, etc.)
    };
    return regionMap[region] || regionMap.NA;
  }

  async authenticate(): Promise<boolean> {
    try {
      const { refreshToken } = this.credentials;

      if (!refreshToken) {
        console.error("Missing Amazon refresh token");
        return false;
      }

      // Test by getting access token
      await this.ensureValidToken();
      return true;
    } catch (error) {
      console.error("Amazon authentication failed:", error);
      return false;
    }
  }

  /**
   * Ensure access token is valid, refresh if needed
   */
  private async ensureValidToken(): Promise<string> {
    const now = Date.now();

    if (this.accessToken && this.tokenExpiresAt && now < this.tokenExpiresAt - 300000) {
      return this.accessToken;
    }

    const creds = await this.lwaHandler.getAccessToken();
    this.accessToken = creds.accessToken;
    this.tokenExpiresAt = creds.expiresAt;

    return creds.accessToken;
  }

  async listProducts(limit = 10, offset = 0): Promise<ProductData[]> {
    try {
      const accessToken = await this.ensureValidToken();
      const baseUrl = this.getBaseUrl();

      const response = await axios.get(
        `${baseUrl}/catalog/2022-04-01/products`,
        {
          headers: this.signer.sign(
            "GET",
            baseUrl.replace("https://", ""),
            "/catalog/2022-04-01/products",
            "",
            accessToken
          ),
          params: {
            pageSize: Math.min(limit, 20),
            pageToken: offset > 0 ? offset : undefined,
          },
        }
      );

      return (response.data.items || []).map((item: any) => ({
        id: item.asin,
        title: item.attributes?.title?.[0]?.value || "",
        description: item.attributes?.description?.[0]?.value || "",
        price: parseFloat(
          item.attributes?.standardPrice?.[0]?.value || "0"
        ),
        currency: item.attributes?.standardPrice?.[0]?.currency || "USD",
        sku: item.sku || item.asin,
        images: item.attributes?.images?.map((img: any) => img.url) || [],
        quantity: parseInt(
          item.attributes?.quantity?.[0]?.value || "0"
        ),
      }));
    } catch (error) {
      console.error("Failed to list Amazon products:", error);
      return [];
    }
  }

  /**
   * Create or update listing using Listings Items API
   */
  async createProduct(product: ProductData): Promise<SyncResult> {
    try {
      const accessToken = await this.ensureValidToken();
      const baseUrl = this.getBaseUrl();
      const marketplaceId = (this.credentials.marketplaceId as string) || "ATVPDKIKX0DER";

      // Prepare payload for Listings Items API
      const payload = {
        attributes: {
          title: [{ value: product.title }],
          brand: [{ value: "MarketplaceConnect" }],
          description: product.description
            ? [{ value: product.description }]
            : undefined,
          standardPrice: [
            {
              currency: product.currency || "USD",
              value: product.price.toFixed(2),
            },
          ],
          quantity: [
            {
              value: Math.floor(product.quantity || 0).toString(),
            },
          ],
          ...(product.weight && {
            weight: [
              {
                value: product.weight.toString(),
                unit: "KG",
              },
            ],
          }),
        },
      };

      const path = `/listings/2021-08-01/listings/${product.sku}`;
      const response = await axios.put(
        `${baseUrl}${path}`,
        payload,
        {
          headers: this.signer.sign("PUT", baseUrl.replace("https://", ""), path, JSON.stringify(payload), accessToken),
          params: { marketplaceIds: marketplaceId },
        }
      );

      return {
        success: true,
        externalId: product.sku,
        message: "Product created on Amazon",
        timestamp: new Date(),
        details: {
          sku: product.sku,
          listingsId: response.data?.listingsId,
        },
      };
    } catch (error) {
      const errorMsg = this.formatError(error);
      return {
        success: false,
        message: `Failed to create Amazon product: ${errorMsg}`,
        timestamp: new Date(),
      };
    }
  }

  async updateProduct(
    externalId: string,
    product: Partial<ProductData>
  ): Promise<SyncResult> {
    try {
      const accessToken = await this.ensureValidToken();
      const baseUrl = this.getBaseUrl();
      const marketplaceId = (this.credentials.marketplaceId as string) || "ATVPDKIKX0DER";

      const payload: any = {
        attributes: {},
      };

      if (product.title) {
        payload.attributes.title = [{ value: product.title }];
      }
      if (product.description) {
        payload.attributes.description = [{ value: product.description }];
      }
      if (product.price && product.price > 0) {
        payload.attributes.standardPrice = [
          {
            currency: product.currency || "USD",
            value: product.price.toFixed(2),
          },
        ];
      }

      const path = `/listings/2021-08-01/listings/${externalId}`;
      await axios.patch(
        `${baseUrl}${path}`,
        payload,
        {
          headers: this.signer.sign("PATCH", baseUrl.replace("https://", ""), path, JSON.stringify(payload), accessToken),
          params: { marketplaceIds: marketplaceId },
        }
      );

      return {
        success: true,
        externalId,
        message: "Product updated on Amazon",
        timestamp: new Date(),
      };
    } catch (error) {
      const errorMsg = this.formatError(error);
      return {
        success: false,
        message: `Failed to update Amazon product: ${errorMsg}`,
        timestamp: new Date(),
      };
    }
  }

  async deleteProduct(externalId: string): Promise<SyncResult> {
    try {
      const accessToken = await this.ensureValidToken();
      const baseUrl = this.getBaseUrl();
      const marketplaceId = (this.credentials.marketplaceId as string) || "ATVPDKIKX0DER";

      const path = `/listings/2021-08-01/listings/${externalId}`;
      await axios.delete(
        `${baseUrl}${path}`,
        {
          headers: this.signer.sign("DELETE", baseUrl.replace("https://", ""), path, "", accessToken),
          params: { marketplaceIds: marketplaceId },
        }
      );

      return {
        success: true,
        externalId,
        message: "Product deleted from Amazon",
        timestamp: new Date(),
      };
    } catch (error) {
      const errorMsg = this.formatError(error);
      return {
        success: false,
        message: `Failed to delete Amazon product: ${errorMsg}`,
        timestamp: new Date(),
      };
    }
  }

  /**
   * Update inventory via Listings Items API
   */
  async syncInventory(externalId: string, quantity: number): Promise<SyncResult> {
    try {
      const accessToken = await this.ensureValidToken();
      const baseUrl = this.getBaseUrl();
      const marketplaceId = (this.credentials.marketplaceId as string) || "ATVPDKIKX0DER";

      const payload = {
        attributes: {
          quantity: [
            {
              value: Math.floor(quantity).toString(),
            },
          ],
        },
      };

      const path = `/listings/2021-08-01/listings/${externalId}`;
      await axios.patch(
        `${baseUrl}${path}`,
        payload,
        {
          headers: this.signer.sign("PATCH", baseUrl.replace("https://", ""), path, JSON.stringify(payload), accessToken),
          params: { marketplaceIds: marketplaceId },
        }
      );

      return {
        success: true,
        externalId,
        message: "Inventory synced to Amazon",
        timestamp: new Date(),
        details: { quantity: Math.floor(quantity) },
      };
    } catch (error) {
      const errorMsg = this.formatError(error);
      return {
        success: false,
        message: `Failed to sync inventory: ${errorMsg}`,
        timestamp: new Date(),
      };
    }
  }

  async handleWebhook(payload: WebhookPayload): Promise<void> {
    console.log("Processing Amazon webhook:", payload.event);
  }

  getDisplayName(): string {
    return "Amazon";
  }

  async validateCredentials(): Promise<boolean> {
    return this.authenticate();
  }

  async getSyncStatus(externalId: string): Promise<Record<string, any>> {
    try {
      const accessToken = await this.ensureValidToken();
      const baseUrl = this.getBaseUrl();
      const marketplaceId = (this.credentials.marketplaceId as string) || "ATVPDKIKX0DER";

      const path = `/listings/2021-08-01/listings/${externalId}`;
      const response = await axios.get(
        `${baseUrl}${path}`,
        {
          headers: this.signer.sign("GET", baseUrl.replace("https://", ""), path, "", accessToken),
          params: { marketplaceIds: marketplaceId },
        }
      );

      return {
        status: "active",
        sku: response.data?.sku,
        title: response.data?.attributes?.title?.[0]?.value,
        price: response.data?.attributes?.standardPrice?.[0]?.value,
        quantity: response.data?.attributes?.quantity?.[0]?.value,
        lastUpdate: new Date(),
      };
    } catch (error) {
      return {
        status: "error",
        message: "Failed to fetch sync status",
      };
    }
  }

  private formatError(error: any): string {
    if (error instanceof AxiosError) {
      const errorData = error.response?.data as any;
      return (
        errorData?.errors?.[0]?.message ||
        errorData?.message ||
        error.message
      );
    }
    return error instanceof Error ? error.message : "Unknown error";
  }
}
