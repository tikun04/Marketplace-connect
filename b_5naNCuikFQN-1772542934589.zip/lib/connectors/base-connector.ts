import { Channel } from "@prisma/client";

export interface ConnectorCredentials {
  [key: string]: string;
}

export interface ProductData {
  id: string;
  title: string;
  description?: string;
  price: number;
  currency: string;
  sku: string;
  images?: string[];
  quantity: number;
  weight?: number;
  dimensions?: {
    length?: number;
    width?: number;
    height?: number;
  };
  [key: string]: any;
}

export interface SyncResult {
  success: boolean;
  externalId?: string;
  message: string;
  timestamp: Date;
  details?: Record<string, any>;
}

export interface WebhookPayload {
  event: string;
  timestamp: Date;
  data: Record<string, any>;
}

export abstract class BaseConnector {
  protected channel: Channel;
  protected credentials: ConnectorCredentials;

  constructor(channel: Channel, credentials: ConnectorCredentials) {
    this.channel = channel;
    this.credentials = credentials;
  }

  /**
   * Authenticate and validate credentials
   */
  abstract authenticate(): Promise<boolean>;

  /**
   * Get list of products from the channel
   */
  abstract listProducts(
    limit?: number,
    offset?: number
  ): Promise<ProductData[]>;

  /**
   * Create a new product on the channel
   */
  abstract createProduct(product: ProductData): Promise<SyncResult>;

  /**
   * Update an existing product on the channel
   */
  abstract updateProduct(
    externalId: string,
    product: Partial<ProductData>
  ): Promise<SyncResult>;

  /**
   * Delete a product from the channel
   */
  abstract deleteProduct(externalId: string): Promise<SyncResult>;

  /**
   * Sync inventory/stock levels
   */
  abstract syncInventory(
    externalId: string,
    quantity: number
  ): Promise<SyncResult>;

  /**
   * Handle incoming webhook events
   */
  abstract handleWebhook(payload: WebhookPayload): Promise<void>;

  /**
   * Get channel-specific display name
   */
  abstract getDisplayName(): string;

  /**
   * Validate if credentials are still valid
   */
  abstract validateCredentials(): Promise<boolean>;

  /**
   * Get sync status for a product
   */
  abstract getSyncStatus(externalId: string): Promise<Record<string, any>>;
}
