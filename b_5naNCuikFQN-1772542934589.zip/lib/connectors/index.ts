import { Channel } from "@prisma/client";
import { BaseConnector, ConnectorCredentials } from "./base-connector";
import { AmazonConnector } from "./amazon-connector";
import { ShopifyConnector } from "./shopify-connector";
import { EbayConnector } from "./ebay-connector";

/**
 * Connector Factory
 * Creates and manages connector instances based on channel type
 */
export class ConnectorFactory {
  private static connectorMap: Record<string, typeof BaseConnector> = {
    AMAZON: AmazonConnector,
    SHOPIFY: ShopifyConnector,
    EBAY: EbayConnector,
  };

  /**
   * Get connector instance for a specific channel
   */
  static getConnector(
    channel: Channel,
    credentials: ConnectorCredentials
  ): BaseConnector {
    const ConnectorClass = this.connectorMap[channel.type];

    if (!ConnectorClass) {
      throw new Error(`Unsupported channel type: ${channel.type}`);
    }

    return new ConnectorClass(channel, credentials);
  }

  /**
   * Get all available connector types
   */
  static getAvailableConnectors(): string[] {
    return Object.keys(this.connectorMap);
  }

  /**
   * Check if connector type is supported
   */
  static isSupported(type: string): boolean {
    return type in this.connectorMap;
  }

  /**
   * Get connector display name
   */
  static getConnectorName(type: string): string {
    const names: Record<string, string> = {
      AMAZON: "Amazon Seller Central",
      SHOPIFY: "Shopify Store",
      EBAY: "eBay Seller Central",
    };
    return names[type] || type;
  }

  /**
   * Get connector icon/emoji
   */
  static getConnectorIcon(type: string): string {
    const icons: Record<string, string> = {
      AMAZON: "🔶",
      SHOPIFY: "🛍️",
      EBAY: "📱",
    };
    return icons[type] || "📦";
  }
}

export { BaseConnector };
export type { ConnectorCredentials, ProductData, SyncResult, WebhookPayload } from "./base-connector";
