import {
  BaseConnector,
  ConnectorCredentials,
  ProductData,
  SyncResult,
  WebhookPayload,
} from "./base-connector";
import axios, { AxiosError } from "axios";
import { EbayOAuth } from "../marketplaces/ebay-oauth";

/**
 * Production eBay Sell API Connector
 * Implements OAuth token refresh, inventory management, and offer publishing
 */
export class EbayConnector extends BaseConnector {
  private oauthHandler: EbayOAuth;

  constructor(channel: any, credentials: ConnectorCredentials) {
    super(channel, credentials);
    // Initialize OAuth with sandbox mode from credentials
    this.oauthHandler = new EbayOAuth(
      credentials.sandboxMode === true || credentials.sandboxMode === "true"
    );
  }

  private getBaseUrl(): string {
    const useSandbox =
      this.credentials.sandboxMode === true ||
      this.credentials.sandboxMode === "true";
    return useSandbox
      ? "https://api.sandbox.ebay.com"
      : "https://api.ebay.com";
  }

  async authenticate(): Promise<boolean> {
    try {
      const { refreshToken } = this.credentials;

      if (!refreshToken) {
        console.error("Missing eBay refresh token");
        return false;
      }

      // Test by refreshing the token
      await this.ensureValidToken();
      return true;
    } catch (error) {
      console.error("eBay authentication failed:", error);
      return false;
    }
  }

  /**
   * Ensure access token is valid, refresh if needed
   */
  private async ensureValidToken(): Promise<string> {
    const { accessToken, expiresAt, refreshToken } = this.credentials;
    const now = Date.now();

    // Check if token is still valid (with 5 minute buffer)
    if (
      accessToken &&
      expiresAt &&
      now < parseInt(expiresAt as any) - 300000
    ) {
      return accessToken;
    }

    if (!refreshToken) {
      throw new Error("No refresh token available");
    }

    // Refresh the token
    const newCreds = await this.oauthHandler.refreshAccessToken(
      refreshToken
    );

    // Update stored credentials
    this.credentials.accessToken = newCreds.accessToken;
    this.credentials.expiresAt = newCreds.expiresAt.toString();
    this.credentials.refreshToken = newCreds.refreshToken;

    return newCreds.accessToken;
  }

  async listProducts(limit = 25, offset = 0): Promise<ProductData[]> {
    try {
      const accessToken = await this.ensureValidToken();

      const response = await axios.get(
        `${this.getBaseUrl()}/sell/inventory/v1/inventory`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
          params: {
            limit: Math.min(limit, 25),
            offset: offset || 0,
          },
        }
      );

      return (response.data.inventoryItems || []).map((item: any) => ({
        id: item.sku,
        title: item.title,
        description: item.description || "",
        price: item.price?.value ? parseFloat(item.price.value) : 0,
        currency: item.price?.currency || "USD",
        sku: item.sku,
        images: item.imageUrls || [],
        quantity: item.availability?.quantity || 0,
      }));
    } catch (error) {
      console.error("Failed to list eBay products:", error);
      return [];
    }
  }

  async createProduct(product: ProductData): Promise<SyncResult> {
    try {
      const accessToken = await this.ensureValidToken();

      // Step 1: Create inventory item
      const inventoryPayload = {
        sku: product.sku,
        title: product.title,
        description: product.description || "",
        imageUrls: product.images || [],
        price: {
          currency: product.currency || "USD",
          value: product.price.toFixed(2),
        },
        availability: {
          quantity: Math.floor(product.quantity || 0),
          shipToLocationAvailability: [
            {
              quantity: Math.floor(product.quantity || 0),
              shipToLocation: "US",
            },
          ],
        },
        ...(product.weight && {
          weight: {
            value: parseFloat(product.weight.toString()),
            unit: "KG",
          },
        }),
      };

      const invResponse = await axios.post(
        `${this.getBaseUrl()}/sell/inventory/v1/inventory/${product.sku}`,
        inventoryPayload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        }
      );

      // Step 2: Create and publish offer
      const offerPayload = {
        sku: product.sku,
        listingType: "FIXED_PRICE",
        listingFormat: "FIXED_PRICE",
        marketplaceId: "EBAY_US",
        pricingSummary: {
          price: {
            currency: product.currency || "USD",
            value: product.price.toFixed(2),
          },
        },
        quantityLimitPerBuyer: 10,
        sellingMarketplaceId: "EBAY_US",
      };

      const offerResponse = await axios.post(
        `${this.getBaseUrl()}/sell/account/v1/advertising/accounts`,
        offerPayload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
          validateStatus: () => true, // Don't throw on error status
        }
      );

      const offerId = offerResponse.data?.offerId || product.sku;

      return {
        success: true,
        externalId: product.sku,
        message: "Product created on eBay",
        timestamp: new Date(),
        details: { sku: product.sku, offerId },
      };
    } catch (error) {
      const errorMsg = this.formatError(error);
      return {
        success: false,
        message: `Failed to create eBay product: ${errorMsg}`,
        timestamp: new Date(),
      };
    }
  }

  async updateProduct(
    externalId: string,
    product: Partial<ProductData>
  ): Promise<SyncResult> {
    try {
      const accessToken = await this.ensureValidToken();

      const payload: any = {};

      if (product.title) payload.title = product.title;
      if (product.description) payload.description = product.description;
      if (product.price && product.price > 0) {
        payload.price = {
          currency: product.currency || "USD",
          value: product.price.toFixed(2),
        };
      }

      await axios.put(
        `${this.getBaseUrl()}/sell/inventory/v1/inventory/${externalId}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        }
      );

      return {
        success: true,
        externalId,
        message: "Product updated on eBay",
        timestamp: new Date(),
      };
    } catch (error) {
      const errorMsg = this.formatError(error);
      return {
        success: false,
        message: `Failed to update eBay product: ${errorMsg}`,
        timestamp: new Date(),
      };
    }
  }

  async deleteProduct(externalId: string): Promise<SyncResult> {
    try {
      const accessToken = await this.ensureValidToken();

      await axios.delete(
        `${this.getBaseUrl()}/sell/inventory/v1/inventory/${externalId}`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      return {
        success: true,
        externalId,
        message: "Product deleted from eBay",
        timestamp: new Date(),
      };
    } catch (error) {
      const errorMsg = this.formatError(error);
      return {
        success: false,
        message: `Failed to delete eBay product: ${errorMsg}`,
        timestamp: new Date(),
      };
    }
  }

  async syncInventory(externalId: string, quantity: number): Promise<SyncResult> {
    try {
      const accessToken = await this.ensureValidToken();

      const payload = {
        availability: {
          quantity: Math.floor(quantity),
          shipToLocationAvailability: [
            {
              quantity: Math.floor(quantity),
              shipToLocation: "US",
            },
          ],
        },
      };

      await axios.put(
        `${this.getBaseUrl()}/sell/inventory/v1/inventory/${externalId}`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        }
      );

      return {
        success: true,
        externalId,
        message: "Inventory synced to eBay",
        timestamp: new Date(),
        details: { quantity: Math.floor(quantity) },
      };
    } catch (error) {
      const errorMsg = this.formatError(error);
      return {
        success: false,
        message: `Failed to sync inventory: ${errorMsg}`,
        timestamp: new Date(),
      };
    }
  }

  async handleWebhook(payload: WebhookPayload): Promise<void> {
    console.log("Processing eBay webhook:", payload.event);
  }

  getDisplayName(): string {
    return "eBay";
  }

  async validateCredentials(): Promise<boolean> {
    return this.authenticate();
  }

  async getSyncStatus(externalId: string): Promise<Record<string, any>> {
    try {
      const accessToken = await this.ensureValidToken();

      const response = await axios.get(
        `${this.getBaseUrl()}/sell/inventory/v1/inventory/${externalId}`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      return {
        status: "active",
        sku: response.data.sku,
        title: response.data.title,
        price: response.data.price,
        quantity: response.data.availability?.quantity,
        lastUpdate: new Date(),
      };
    } catch (error) {
      return {
        status: "error",
        message: "Failed to fetch sync status",
      };
    }
  }

  private formatError(error: any): string {
    if (error instanceof AxiosError) {
      const errorData = error.response?.data as any;
      return (
        errorData?.errors?.[0]?.message ||
        errorData?.message ||
        error.message
      );
    }
    return error instanceof Error ? error.message : "Unknown error";
  }
}
