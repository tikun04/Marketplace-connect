import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default async function SettingsPage() {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Get user and team info
  const user = await db.user.findUnique({
    where: { id: session.user.id },
    include: {
      teams: {
        include: {
          members: true,
        },
      },
    },
  });

  if (!user || !user.teams.length) {
    redirect("/auth/signin");
  }

  const team = user.teams[0];
  const currentMember = team.members.find((m) => m.userId === session.user.id);

  return (
    <div className="space-y-8">
      <DashboardHeader
        title="Settings"
        description="Manage your account and team settings"
      />

      {/* Profile Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Profile</CardTitle>
          <CardDescription>Your account information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground">Name</p>
            <p className="font-medium">{user.name}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Email</p>
            <p className="font-medium">{user.email}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Member Since</p>
            <p className="text-sm">
              {new Date(user.createdAt).toLocaleDateString()}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Team Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Team</CardTitle>
          <CardDescription>Manage your team and members</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground">Team Name</p>
            <p className="font-medium">{team.name}</p>
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-3">Members</p>
            <div className="space-y-2">
              {team.members.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div>
                    <p className="font-medium">{member.userId}</p>
                  </div>
                  <Badge variant="outline">{member.role}</Badge>
                </div>
              ))}
            </div>
          </div>

          {currentMember?.role === "OWNER" && (
            <Link href="/settings/team-members">
              <Button variant="outline">Manage Members</Button>
            </Link>
          )}
        </CardContent>
      </Card>

      {/* API Settings */}
      <Card>
        <CardHeader>
          <CardTitle>API Configuration</CardTitle>
          <CardDescription>
            Configure webhooks and API settings
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <p className="text-sm font-medium mb-2">Webhook Endpoints</p>
            <p className="text-xs text-muted-foreground mb-3">
              Configure these URLs in your channel settings to receive real-time updates
            </p>
            <div className="space-y-2">
              <div className="bg-background p-2 rounded border font-mono text-xs break-all">
                https://yourdomain.com/api/webhooks
              </div>
            </div>
          </div>

          <div className="p-4 bg-amber-50 dark:bg-amber-950 rounded-lg">
            <p className="text-sm font-medium mb-2">Cron Jobs</p>
            <p className="text-xs text-muted-foreground">
              Background sync jobs run automatically. You don't need to configure anything.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="border-red-200 dark:border-red-800">
        <CardHeader>
          <CardTitle className="text-red-600">Danger Zone</CardTitle>
          <CardDescription>
            Irreversible actions that affect your account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-4 border border-red-200 dark:border-red-800 rounded-lg">
            <p className="font-medium text-sm mb-2">Delete Account</p>
            <p className="text-sm text-muted-foreground mb-3">
              This will permanently delete your account and all associated data.
            </p>
            <Button variant="destructive" disabled>
              Delete Account
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
