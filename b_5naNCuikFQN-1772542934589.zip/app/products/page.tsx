import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default async function ProductsPage() {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Get user's team
  const team = await db.team.findFirst({
    where: {
      members: {
        some: {
          userId: session.user.id,
        },
      },
    },
  });

  if (!team) {
    redirect("/auth/signin");
  }

  // Get products with sync info
  const products = await db.product.findMany({
    where: { teamId: team.id },
    include: {
      syncs: {
        orderBy: { createdAt: "desc" },
        take: 3,
      },
      _count: {
        select: { syncs: true },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return (
    <div className="space-y-8">
      <DashboardHeader
        title="Products"
        description="Manage products across all channels"
        action={{
          label: "Create Product",
          href: "/products/new",
        }}
      />

      {products.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground mb-4">No products yet</p>
          <Link href="/products/new">
            <Button>Create Your First Product</Button>
          </Link>
        </Card>
      ) : (
        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted">
                <TableHead>Title</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Syncs</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) => {
                const syncedChannels = Object.keys(
                  (product.externalIds as Record<string, string>) || {}
                ).length;
                const lastSync = product.syncs[0];

                return (
                  <TableRow key={product.id}>
                    <TableCell className="font-medium">
                      <Link
                        href={`/products/${product.id}`}
                        className="hover:underline"
                      >
                        {product.title}
                      </Link>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {product.sku}
                    </TableCell>
                    <TableCell>${product.price.toFixed(2)}</TableCell>
                    <TableCell>{product.quantity}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{syncedChannels} channels</Badge>
                    </TableCell>
                    <TableCell>
                      {lastSync ? (
                        <Badge
                          variant={
                            lastSync.status === "SUCCESS"
                              ? "default"
                              : "destructive"
                          }
                        >
                          {lastSync.status}
                        </Badge>
                      ) : (
                        <Badge variant="secondary">Not synced</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Link href={`/products/${product.id}`}>
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
