import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import { ProductForm } from "@/components/product-form";

export default async function NewProductPage() {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Verify user has a team
  const team = await db.team.findFirst({
    where: {
      members: {
        some: {
          userId: session.user.id,
        },
      },
    },
  });

  if (!team) {
    redirect("/auth/signin");
  }

  return (
    <div className="space-y-8 max-w-2xl">
      <DashboardHeader
        title="Create New Product"
        description="Add a new product to your catalog. You can sync it to your connected channels afterwards."
      />

      <ProductForm />
    </div>
  );
}
