import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import { ProductForm } from "@/components/product-form";
import { ProductSyncDialog } from "@/components/product-sync-dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default async function ProductDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Get product and verify access
  const product = await db.product.findUnique({
    where: { id: params.id },
    include: {
      team: { include: { members: true } },
      syncs: {
        orderBy: { createdAt: "desc" },
        take: 20,
      },
    },
  });

  if (!product) {
    redirect("/products");
  }

  // Verify team access
  const hasMemberAccess = product.team.members.some(
    (m) => m.userId === session.user.id
  );

  if (!hasMemberAccess) {
    redirect("/products");
  }

  // Get channels for sync dialog
  const channels = await db.channel.findMany({
    where: { teamId: product.teamId },
  });

  const syncedChannels = Object.keys(
    (product.externalIds as Record<string, string>) || {}
  ).length;

  return (
    <div className="space-y-8">
      <DashboardHeader
        title={product.title}
        description={`SKU: ${product.sku}`}
        action={{
          label: "Back to Products",
          href: "/products",
        }}
      />

      {/* Product Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Product Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Price</p>
              <p className="text-2xl font-bold">${product.price.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Stock Quantity</p>
              <p className="text-2xl font-bold">{product.quantity} units</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Created</p>
              <p className="text-sm">
                {new Date(product.createdAt).toLocaleDateString()}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sync Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Synced to Channels</p>
              <p className="text-2xl font-bold">{syncedChannels}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Last Sync</p>
              <p className="text-sm">
                {product.syncedAt
                  ? new Date(product.syncedAt).toLocaleDateString()
                  : "Not synced"}
              </p>
            </div>
            {channels.length > 0 && (
              <ProductSyncDialog
                productId={product.id}
                productTitle={product.title}
                channels={channels}
                onSyncComplete={() => {
                  // Trigger a refresh
                  window.location.reload();
                }}
              />
            )}
          </CardContent>
        </Card>
      </div>

      {/* Description */}
      {product.description && (
        <Card>
          <CardHeader>
            <CardTitle>Description</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground whitespace-pre-wrap">
              {product.description}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Images */}
      {product.images && (product.images as string[]).length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Product Images</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
              {(product.images as string[]).map((image, idx) => (
                <img
                  key={idx}
                  src={image}
                  alt={`Product image ${idx + 1}`}
                  className="w-full h-40 object-cover rounded-lg"
                />
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Sync History */}
      <Card>
        <CardHeader>
          <CardTitle>Sync History</CardTitle>
          <CardDescription>
            Recent synchronization operations for this product
          </CardDescription>
        </CardHeader>
        <CardContent>
          {product.syncs.length === 0 ? (
            <p className="text-muted-foreground">No syncs yet</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Channel</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {product.syncs.map((sync) => (
                    <TableRow key={sync.id}>
                      <TableCell className="font-medium">
                        {channels.find((c) => c.id === sync.channelId)?.name ||
                          "Unknown"}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            sync.status === "SUCCESS"
                              ? "default"
                              : "destructive"
                          }
                        >
                          {sync.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {sync.message}
                      </TableCell>
                      <TableCell className="text-sm">
                        {new Date(sync.createdAt).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
