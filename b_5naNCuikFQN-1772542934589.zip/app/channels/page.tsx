import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import { ChannelCard } from "@/components/channel-card";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default async function ChannelsPage() {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Get user's team
  const team = await db.team.findFirst({
    where: {
      members: {
        some: {
          userId: session.user.id,
        },
      },
    },
  });

  if (!team) {
    redirect("/auth/signin");
  }

  // Get channels with sync stats
  const channels = await db.channel.findMany({
    where: { teamId: team.id },
    include: {
      _count: {
        select: { syncs: true },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  // Get latest sync for each channel
  const channelsWithStats = await Promise.all(
    channels.map(async (channel) => {
      const lastSync = await db.syncLog.findFirst({
        where: { channelId: channel.id },
        orderBy: { createdAt: "desc" },
      });

      return {
        ...channel,
        syncCount: channel._count.syncs,
        lastSync: lastSync?.createdAt,
      };
    })
  );

  return (
    <div className="space-y-8">
      <DashboardHeader
        title="Channels"
        description="Manage your sales channel connections"
        action={{
          label: "Connect Channel",
          href: "/channels/new",
        }}
      />

      {channelsWithStats.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground mb-4">
            No channels connected yet
          </p>
          <Link href="/channels/new">
            <Button>Connect Your First Channel</Button>
          </Link>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {channelsWithStats.map((channel) => (
            <ChannelCard key={channel.id} channel={channel} />
          ))}
        </div>
      )}
    </div>
  );
}
