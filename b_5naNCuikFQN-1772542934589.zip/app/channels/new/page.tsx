import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import { ChannelForm } from "@/components/channel-form";

export default async function NewChannelPage() {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Verify user has a team with admin access
  const team = await db.team.findFirst({
    where: {
      members: {
        some: {
          userId: session.user.id,
          role: { in: ["OWNER", "ADMIN"] },
        },
      },
    },
  });

  if (!team) {
    redirect("/channels");
  }

  return (
    <div className="space-y-8">
      <DashboardHeader
        title="Connect Sales Channel"
        description="Add a new marketplace connection to sync your products"
      />

      <ChannelForm />
    </div>
  );
}
