import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ConnectorFactory } from "@/lib/connectors";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default async function ChannelDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Get channel and verify access
  const channel = await db.channel.findUnique({
    where: { id: params.id },
    include: {
      team: { include: { members: true } },
      syncs: {
        orderBy: { createdAt: "desc" },
        take: 20,
        include: {
          product: {
            select: {
              id: true,
              title: true,
              sku: true,
            },
          },
        },
      },
    },
  });

  if (!channel) {
    redirect("/channels");
  }

  // Verify team access
  const hasMemberAccess = channel.team.members.some(
    (m) => m.userId === session.user.id
  );

  if (!hasMemberAccess) {
    redirect("/channels");
  }

  const connectorName = ConnectorFactory.getConnectorName(channel.type);
  const icon = ConnectorFactory.getConnectorIcon(channel.type);

  const stats = {
    synced: channel.syncs.length,
    successful: channel.syncs.filter((s) => s.status === "SUCCESS").length,
    failed: channel.syncs.filter((s) => s.status === "FAILED").length,
  };

  return (
    <div className="space-y-8">
      <DashboardHeader
        title={channel.name}
        description={`Connected to ${connectorName}`}
        action={{
          label: "Back to Channels",
          href: "/channels",
        }}
      />

      {/* Channel Info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <span className="text-2xl">{icon}</span>
              {connectorName}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Badge
              className={
                channel.status === "ACTIVE"
                  ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                  : "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300"
              }
            >
              {channel.status}
            </Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground">
              Products Synced
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{stats.synced}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground">
              Last Sync
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm">
              {channel.lastSync
                ? new Date(channel.lastSync).toLocaleDateString()
                : "Never"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Sync Stats */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground">
              Successful Syncs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600">{stats.successful}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground">
              Failed Syncs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-red-600">{stats.failed}</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Syncs */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Sync Operations</CardTitle>
          <CardDescription>
            Latest product synchronization to this channel
          </CardDescription>
        </CardHeader>
        <CardContent>
          {channel.syncs.length === 0 ? (
            <p className="text-muted-foreground">No syncs yet</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {channel.syncs.map((sync) => (
                    <TableRow key={sync.id}>
                      <TableCell>
                        <Link
                          href={`/products/${sync.product.id}`}
                          className="hover:underline font-medium"
                        >
                          {sync.product.title}
                        </Link>
                        <p className="text-xs text-muted-foreground">
                          {sync.product.sku}
                        </p>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            sync.status === "SUCCESS"
                              ? "default"
                              : "destructive"
                          }
                        >
                          {sync.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm max-w-xs truncate">
                        {sync.message}
                      </TableCell>
                      <TableCell className="text-sm">
                        {new Date(sync.createdAt).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Channel Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Channel Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm text-muted-foreground">Connection Name</p>
            <p className="font-medium">{channel.name}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Created</p>
            <p className="text-sm">
              {new Date(channel.createdAt).toLocaleDateString()}
            </p>
          </div>
          <Link href={`/channels/${channel.id}/settings`}>
            <Button>Manage Settings</Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
