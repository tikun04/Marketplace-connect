import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";

export default async function HomePage() {
  const session = await getServerSession(authConfig);

  if (session?.user?.id) {
    redirect("/dashboard");
  }

  redirect("/auth/signin");
}
