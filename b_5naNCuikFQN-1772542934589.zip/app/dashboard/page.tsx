import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChannelCard } from "@/components/channel-card";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default async function DashboardPage() {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Get user's team
  const team = await db.team.findFirst({
    where: {
      members: {
        some: {
          userId: session.user.id,
        },
      },
    },
    include: {
      channels: {
        orderBy: { createdAt: "desc" },
      },
      _count: {
        select: {
          products: true,
          channels: true,
        },
      },
    },
  });

  if (!team) {
    redirect("/auth/signin");
  }

  // Get sync stats
  const syncStats = await db.syncLog.groupBy({
    by: ["status"],
    where: {
      product: {
        teamId: team.id,
      },
    },
    _count: true,
  });

  const stats = {
    products: team._count.products,
    channels: team._count.channels,
    successfulSyncs: syncStats.find((s) => s.status === "SUCCESS")?._count || 0,
    failedSyncs: syncStats.find((s) => s.status === "FAILED")?._count || 0,
  };

  return (
    <div className="space-y-8">
      <DashboardHeader
        title="Marketplace Connect"
        description="Manage your multi-channel product synchronization"
        action={{
          label: "New Product",
          href: "/products/new",
        }}
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Products
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.products}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats.products === 1 ? "product" : "products"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Connected Channels
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.channels}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats.channels === 1 ? "channel" : "channels"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Successful Syncs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {stats.successfulSyncs}
            </div>
            <p className="text-xs text-muted-foreground mt-1">last 30 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Failed Syncs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {stats.failedSyncs}
            </div>
            <p className="text-xs text-muted-foreground mt-1">needs attention</p>
          </CardContent>
        </Card>
      </div>

      {/* Channels Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Connected Channels</h2>
            <p className="text-muted-foreground">
              Your active sales channels
            </p>
          </div>
          <Link href="/channels/new">
            <Button>Connect Channel</Button>
          </Link>
        </div>

        {team.channels.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground mb-4">
              No channels connected yet
            </p>
            <Link href="/channels/new">
              <Button>Connect Your First Channel</Button>
            </Link>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {team.channels.map((channel) => (
              <ChannelCard key={channel.id} channel={channel} />
            ))}
          </div>
        )}
      </div>

      {/* Quick Links */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Link href="/products">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle>Browse Products</CardTitle>
              <CardDescription>
                View and manage all your products
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-muted-foreground">
                {stats.products}
              </p>
            </CardContent>
          </Card>
        </Link>

        <Link href="/sync-history">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <CardTitle>Sync History</CardTitle>
              <CardDescription>
                View detailed sync logs and status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-muted-foreground">
                {stats.successfulSyncs + stats.failedSyncs}
              </p>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
