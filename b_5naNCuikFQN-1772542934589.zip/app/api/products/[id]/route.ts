import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { db } from "@/lib/db";
import { authConfig } from "@/lib/auth";
import { productSchema } from "@/lib/validators";
import { ZodError } from "zod";

/**
 * GET /api/products/[id]
 * Get a specific product
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authConfig);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const product = await db.product.findUnique({
      where: { id: params.id },
      include: { team: { include: { members: true } } },
    });

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    // Verify team access
    const hasMemberAccess = product.team.members.some(
      (m) => m.userId === session.user.id
    );

    if (!hasMemberAccess) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    return NextResponse.json(product);
  } catch (error) {
    console.error("GET /api/products/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to fetch product" },
      { status: 500 }
    );
  }
}

/**
 * PATCH /api/products/[id]
 * Update a product
 */
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authConfig);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const validated = productSchema.partial().parse(body);

    // Get product and verify access
    const product = await db.product.findUnique({
      where: { id: params.id },
      include: { team: { include: { members: true } } },
    });

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    // Verify team access
    const hasMemberAccess = product.team.members.some(
      (m) => m.userId === session.user.id
    );

    if (!hasMemberAccess) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // Update product
    const updated = await db.product.update({
      where: { id: params.id },
      data: validated,
    });

    return NextResponse.json(updated);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      );
    }

    console.error("PATCH /api/products/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to update product" },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/products/[id]
 * Delete a product
 */
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authConfig);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get product and verify access
    const product = await db.product.findUnique({
      where: { id: params.id },
      include: { team: { include: { members: true } } },
    });

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 });
    }

    // Verify team access
    const hasMemberAccess = product.team.members.some(
      (m) => m.userId === session.user.id
    );

    if (!hasMemberAccess) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // Delete product and associated sync logs
    await Promise.all([
      db.syncLog.deleteMany({ where: { productId: params.id } }),
      db.product.delete({ where: { id: params.id } }),
    ]);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/products/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to delete product" },
      { status: 500 }
    );
  }
}
