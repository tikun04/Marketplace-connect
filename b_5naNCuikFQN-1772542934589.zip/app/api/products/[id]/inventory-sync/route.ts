import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { SyncEngine } from "@/lib/sync-engine";

/**
 * Sync inventory for a product across all connected channels
 * POST /api/products/{id}/inventory-sync
 * Body: { teamId }
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const productId = params.id;
    const body = await request.json();
    const { teamId } = body;

    if (!teamId) {
      return NextResponse.json(
        { error: "teamId is required" },
        { status: 400 }
      );
    }

    // Verify product exists and belongs to team
    const product = await db.product.findUnique({
      where: { id: productId },
      include: {
        channelListings: true,
      },
    });

    if (!product || product.teamId !== teamId) {
      return NextResponse.json(
        { error: "Product not found" },
        { status: 404 }
      );
    }

    if (product.channelListings.length === 0) {
      return NextResponse.json(
        {
          error: "Product is not listed on any channels",
          productId,
        },
        { status: 400 }
      );
    }

    // Sync inventory across all channels
    const results = await SyncEngine.syncInventoryToChannels(teamId, productId);

    return NextResponse.json({
      productId,
      inventory: product.inventory,
      timestamp: new Date(),
      results,
    });
  } catch (error) {
    console.error("Inventory sync error:", error);

    return NextResponse.json(
      {
        error: "Failed to sync inventory",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}

/**
 * Get inventory sync history
 * GET /api/products/{id}/inventory-sync?teamId=xxx&limit=10
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const teamId = searchParams.get("teamId");
    const limit = parseInt(searchParams.get("limit") || "10");
    const productId = params.id;

    if (!teamId) {
      return NextResponse.json(
        { error: "teamId is required" },
        { status: 400 }
      );
    }

    // Get recent syncs for all channels (inventory-related)
    const syncs = await db.sync.findMany({
      where: {
        productId,
        teamId,
      },
      include: {
        logs: {
          orderBy: { createdAt: "asc" },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
      take: limit,
    });

    return NextResponse.json({
      productId,
      count: syncs.length,
      syncs: syncs.map((sync) => ({
        id: sync.id,
        channel: sync.channel,
        status: sync.status,
        errorMessage: sync.errorMessage,
        startedAt: sync.startedAt,
        completedAt: sync.completedAt,
        createdAt: sync.createdAt,
      })),
    });
  } catch (error) {
    console.error("Get inventory sync history error:", error);

    return NextResponse.json(
      {
        error: "Failed to get inventory sync history",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}
