import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { Channel } from "@prisma/client";
import { SyncEngine } from "@/lib/sync-engine";

/**
 * Sync a product to specific channels
 * POST /api/products/{id}/sync
 * Body: { teamId, channels: ["SHOPIFY", "EBAY"], action?: "create" | "update" | "delete" }
 */
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const productId = params.id;
    const body = await request.json();
    const { teamId, channels, action = "create" } = body;

    if (!teamId) {
      return NextResponse.json(
        { error: "teamId is required" },
        { status: 400 }
      );
    }

    if (!Array.isArray(channels) || channels.length === 0) {
      return NextResponse.json(
        { error: "channels array is required with at least one channel" },
        { status: 400 }
      );
    }

    // Verify product exists and belongs to team
    const product = await db.product.findUnique({
      where: { id: productId },
    });

    if (!product || product.teamId !== teamId) {
      return NextResponse.json(
        { error: "Product not found" },
        { status: 404 }
      );
    }

    const results = [];

    // Sync to each channel
    for (const channelName of channels) {
      if (!Object.values(Channel).includes(channelName)) {
        results.push({
          channel: channelName,
          success: false,
          message: "Invalid channel name",
        });
        continue;
      }

      try {
        const result = await SyncEngine.syncProductToChannel(
          teamId,
          productId,
          channelName as Channel,
          action as "create" | "update" | "delete"
        );

        results.push({
          channel: channelName,
          ...result,
        });
      } catch (error) {
        results.push({
          channel: channelName,
          success: false,
          message: error instanceof Error ? error.message : "Unknown error",
        });
      }
    }

    return NextResponse.json({
      productId,
      timestamp: new Date(),
      results,
    });
  } catch (error) {
    console.error("Product sync error:", error);

    return NextResponse.json(
      {
        error: "Failed to sync product",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}

/**
 * Get sync history for a product
 * GET /api/products/{id}/sync?teamId=xxx&channel=SHOPIFY&limit=10
 */
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const teamId = searchParams.get("teamId");
    const channel = searchParams.get("channel");
    const limit = parseInt(searchParams.get("limit") || "10");
    const productId = params.id;

    if (!teamId) {
      return NextResponse.json(
        { error: "teamId is required" },
        { status: 400 }
      );
    }

    // Build query filter
    const where: any = {
      productId,
      teamId,
    };

    if (channel) {
      where.channel = channel;
    }

    // Get sync history with logs
    const syncs = await db.sync.findMany({
      where,
      include: {
        logs: {
          orderBy: { createdAt: "asc" },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
      take: limit,
    });

    return NextResponse.json({
      productId,
      count: syncs.length,
      syncs: syncs.map((sync) => ({
        id: sync.id,
        channel: sync.channel,
        status: sync.status,
        errorMessage: sync.errorMessage,
        startedAt: sync.startedAt,
        completedAt: sync.completedAt,
        createdAt: sync.createdAt,
        logs: sync.logs,
      })),
    });
  } catch (error) {
    console.error("Get sync history error:", error);

    return NextResponse.json(
      {
        error: "Failed to get sync history",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}
