import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ConnectorFactory } from "@/lib/connectors";
import { decryptCredentials } from "@/lib/encryption";

/**
 * GET /api/cron/sync
 * Vercel Cron job for periodic product syncing
 * Configure in vercel.json: { schedule: "0 */6 * * *" } (every 6 hours)
 */
export async function GET(request: NextRequest) {
  try {
    // Verify cron secret
    const authHeader = request.headers.get("authorization");
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    console.log("[Cron] Starting periodic sync job");

    // Find products that need syncing
    const productsNeedingSync = await db.product.findMany({
      where: {
        syncedAt: {
          lt: new Date(Date.now() - 24 * 60 * 60 * 1000), // Not synced in 24 hours
        },
      },
      include: {
        team: {
          include: {
            channels: true,
          },
        },
      },
      take: 100,
    });

    console.log(`[Cron] Found ${productsNeedingSync.length} products to sync`);

    let successCount = 0;
    let failureCount = 0;

    for (const product of productsNeedingSync) {
      for (const channel of product.team.channels) {
        try {
          const credentials = decryptCredentials(channel.credentials);
          const connector = ConnectorFactory.getConnector(channel, credentials);

          let syncResult;

          if (product.externalIds && product.externalIds[channel.id]) {
            syncResult = await connector.updateProduct(
              product.externalIds[channel.id],
              {
                title: product.title,
                description: product.description || undefined,
                price: product.price,
                sku: product.sku,
                images: product.images as string[],
                quantity: product.quantity,
              }
            );
          } else {
            syncResult = await connector.createProduct({
              id: product.id,
              title: product.title,
              description: product.description || undefined,
              price: product.price,
              currency: "USD",
              sku: product.sku,
              images: product.images as string[],
              quantity: product.quantity,
            });
          }

          if (syncResult.success) {
            successCount++;

            // Update external IDs if needed
            if (syncResult.externalId) {
              const externalIds = (product.externalIds as Record<string, string>) || {};
              externalIds[channel.id] = syncResult.externalId;

              await db.product.update({
                where: { id: product.id },
                data: {
                  externalIds,
                  syncedAt: new Date(),
                },
              });
            }
          } else {
            failureCount++;
          }

          // Log sync
          await db.syncLog.create({
            data: {
              productId: product.id,
              channelId: channel.id,
              status: syncResult.success ? "SUCCESS" : "FAILED",
              message: syncResult.message,
              details: JSON.stringify(syncResult.details || {}),
              externalId: syncResult.externalId,
            },
          });
        } catch (error) {
          failureCount++;
          console.error(
            `[Cron] Error syncing product ${product.id} to channel ${channel.id}:`,
            error
          );
        }
      }
    }

    console.log(
      `[Cron] Sync complete: ${successCount} successes, ${failureCount} failures`
    );

    return NextResponse.json({
      status: "completed",
      productsProcessed: productsNeedingSync.length,
      successCount,
      failureCount,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error("[Cron] Sync job failed:", error);
    return NextResponse.json(
      {
        error: "Cron job failed",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}
