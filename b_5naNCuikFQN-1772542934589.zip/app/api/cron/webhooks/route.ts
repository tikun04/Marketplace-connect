import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ConnectorFactory } from "@/lib/connectors";
import { decryptCredentials } from "@/lib/encryption";

/**
 * GET /api/cron/webhooks
 * Vercel Cron job for processing webhook events
 * Configure in vercel.json: { schedule: "*/5 * * * *" } (every 5 minutes)
 */
export async function GET(request: NextRequest) {
  try {
    // Verify cron secret
    const authHeader = request.headers.get("authorization");
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    console.log("[Cron] Starting webhook processing job");

    // Find pending webhook events
    const pendingEvents = await db.webhookEvent.findMany({
      where: { status: "PENDING" },
      take: 50,
    });

    console.log(`[Cron] Found ${pendingEvents.length} pending webhook events`);

    let processedCount = 0;
    let failureCount = 0;

    for (const event of pendingEvents) {
      try {
        const payload = JSON.parse(event.payload);

        // Route to appropriate handler based on source
        switch (event.source) {
          case "AMAZON":
            await handleAmazonWebhook(payload);
            break;
          case "SHOPIFY":
            await handleShopifyWebhook(payload);
            break;
          case "EBAY":
            await handleEbayWebhook(payload);
            break;
        }

        // Mark as processed
        await db.webhookEvent.update({
          where: { id: event.id },
          data: { status: "PROCESSED", processedAt: new Date() },
        });

        processedCount++;
      } catch (error) {
        failureCount++;

        // Update retry count
        const currentRetries = (event.retries || 0) + 1;

        if (currentRetries > 5) {
          // Max retries reached
          await db.webhookEvent.update({
            where: { id: event.id },
            data: { status: "FAILED", retries: currentRetries },
          });
        } else {
          // Reset to pending for retry
          await db.webhookEvent.update({
            where: { id: event.id },
            data: { retries: currentRetries },
          });
        }

        console.error(
          `[Cron] Error processing webhook ${event.id}:`,
          error
        );
      }
    }

    console.log(
      `[Cron] Webhook processing complete: ${processedCount} processed, ${failureCount} failed`
    );

    return NextResponse.json({
      status: "completed",
      eventsProcessed: processedCount,
      eventsFailed: failureCount,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error("[Cron] Webhook processing job failed:", error);
    return NextResponse.json(
      {
        error: "Cron job failed",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}

/**
 * Handle Amazon webhook events
 */
async function handleAmazonWebhook(payload: Record<string, any>) {
  // Handle price, inventory, or listing changes
  const eventType = payload.eventType || payload.event;

  if (eventType === "INVENTORY_CHANGED") {
    // Update product inventory
    console.log("[Amazon] Inventory changed:", payload.sku);
  } else if (eventType === "PRICE_CHANGED") {
    // Update product price
    console.log("[Amazon] Price changed:", payload.sku);
  }
}

/**
 * Handle Shopify webhook events
 */
async function handleShopifyWebhook(payload: Record<string, any>) {
  const eventType = payload.eventType || payload.event;

  if (eventType === "PRODUCT_UPDATED") {
    // Handle product update
    const product = payload.product;
    console.log("[Shopify] Product updated:", product.id);
  } else if (eventType === "INVENTORY_CHANGED") {
    // Handle inventory update
    console.log("[Shopify] Inventory changed");
  }
}

/**
 * Handle eBay webhook events
 */
async function handleEbayWebhook(payload: Record<string, any>) {
  const eventType = payload.eventType || payload.event;

  if (eventType === "LISTING_CHANGED") {
    // Handle listing update
    const listing = payload.listing;
    console.log("[eBay] Listing changed:", listing.sku);
  } else if (eventType === "ITEM_SOLD") {
    // Handle sold notification
    console.log("[eBay] Item sold");
  }
}
