import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import bcryptjs from "bcryptjs";
import { z } from "zod";

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(2),
  teamName: z.string().optional(),
});

/**
 * POST /api/auth/register
 * Register a new user and create a team
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, name, teamName } = registerSchema.parse(body);

    // Check if user exists
    const existingUser = await db.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      return NextResponse.json(
        { message: "User already exists" },
        { status: 400 }
      );
    }

    // Hash password
    const hashedPassword = await bcryptjs.hash(password, 10);

    // Create user and team in transaction
    const user = await db.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        teams: {
          create: {
            name: teamName || `${name}'s Team`,
            members: {
              create: {
                userId: "", // Will be set to the created user ID
                role: "OWNER",
              },
            },
          },
        },
      },
    });

    // Get the team and update the member
    const team = await db.team.findFirst({
      where: {
        members: {
          some: {
            role: "OWNER",
          },
        },
      },
    });

    if (!team) {
      throw new Error("Failed to create team");
    }

    // Update the member with the user ID
    await db.teamMember.updateMany({
      where: {
        teamId: team.id,
        userId: "",
      },
      data: {
        userId: user.id,
      },
    });

    return NextResponse.json(
      {
        message: "Account created successfully",
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { message: "Validation error", errors: error.errors },
        { status: 400 }
      );
    }

    console.error("Registration error:", error);
    return NextResponse.json(
      { message: "Failed to register user" },
      { status: 500 }
    );
  }
}
