import { NextRequest, NextResponse } from "next/server";
import { EbayOAuth } from "@/lib/marketplaces/ebay-oauth";

/**
 * Initialize eBay OAuth flow
 * POST /api/oauth/ebay/init with { teamId, sandboxMode }
 */
export async function POST(request: NextRequest) {
  try {
    const { teamId, sandboxMode } = await request.json();

    if (!teamId) {
      return NextResponse.json(
        { error: "teamId is required" },
        { status: 400 }
      );
    }

    const ebayOAuth = new EbayOAuth(sandboxMode || false);

    // Create state token (encode teamId and sandbox mode)
    const state = Buffer.from(
      JSON.stringify({ teamId, sandboxMode: sandboxMode || false })
    ).toString("base64");

    // Generate authorization URL
    const authUrl = ebayOAuth.generateAuthUrl(state);

    return NextResponse.json({ authUrl });
  } catch (error) {
    console.error("eBay OAuth init error:", error);

    return NextResponse.json(
      {
        error: "Failed to initialize eBay authentication",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}
