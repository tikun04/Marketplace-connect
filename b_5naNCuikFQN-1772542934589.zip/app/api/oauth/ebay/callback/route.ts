import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { encryptCredentials } from "@/lib/encryption";
import { EbayOAuth } from "@/lib/marketplaces/ebay-oauth";

/**
 * eBay OAuth callback handler
 * GET /api/oauth/ebay/callback?code=xxx&state=xxx
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const code = searchParams.get("code");
    const state = searchParams.get("state");

    if (!code || !state) {
      return NextResponse.json(
        { error: "Missing required OAuth parameters" },
        { status: 400 }
      );
    }

    // Decode state to get teamId and sandbox mode
    const decodedState = JSON.parse(Buffer.from(state, "base64").toString("utf-8"));
    const { teamId, sandboxMode } = decodedState;

    if (!teamId) {
      return NextResponse.json(
        { error: "Invalid state token" },
        { status: 400 }
      );
    }

    // Check if user has access to this team
    const team = await db.team.findUnique({
      where: { id: teamId },
    });

    if (!team) {
      return NextResponse.json(
        { error: "Team not found" },
        { status: 404 }
      );
    }

    // Exchange code for tokens
    const ebayOAuth = new EbayOAuth(sandboxMode);
    const credentials = await ebayOAuth.exchangeCodeForToken(code);

    // Encrypt and store credentials
    const encryptedCreds = encryptCredentials(
      ebayOAuth.formatCredentials(credentials)
    );

    // Update or create channel credentials
    await db.channelCredentials.upsert({
      where: {
        teamId_channel: {
          teamId,
          channel: "EBAY",
        },
      },
      update: {
        credentialsEncrypted: encryptedCreds,
        isActive: true,
        lastVerified: new Date(),
      },
      create: {
        teamId,
        channel: "EBAY",
        credentialsEncrypted: encryptedCreds,
        isActive: true,
        lastVerified: new Date(),
      },
    });

    // Redirect to success page
    return NextResponse.redirect(
      new URL(
        `/dashboard/${teamId}/channels?success=ebay_connected`,
        request.url
      )
    );
  } catch (error) {
    console.error("eBay OAuth callback error:", error);

    return NextResponse.json(
      {
        error: "Failed to complete eBay authentication",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}
