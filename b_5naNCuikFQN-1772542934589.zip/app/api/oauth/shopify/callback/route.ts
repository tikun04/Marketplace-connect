import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { decryptCredentials, encryptCredentials } from "@/lib/encryption";
import { ShopifyOAuth } from "@/lib/marketplaces/shopify-oauth";

/**
 * Shopify OAuth callback handler
 * POST /api/oauth/shopify/callback?code=xxx&shop=xxx&state=xxx
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const code = searchParams.get("code");
    const shop = searchParams.get("shop");
    const state = searchParams.get("state");

    if (!code || !shop || !state) {
      return NextResponse.json(
        { error: "Missing required OAuth parameters" },
        { status: 400 }
      );
    }

    // Verify state token (in production, validate against session storage)
    // For now, we'll accept it - implement proper state validation in production

    const shopifyOAuth = new ShopifyOAuth();
    const credentials = await shopifyOAuth.exchangeCodeForToken(shop, code);

    // Decode state to get teamId
    const teamId = Buffer.from(state, "base64").toString("utf-8");

    // Check if user has access to this team
    const team = await db.team.findUnique({
      where: { id: teamId },
    });

    if (!team) {
      return NextResponse.json(
        { error: "Team not found" },
        { status: 404 }
      );
    }

    // Encrypt and store credentials
    const encryptedCreds = encryptCredentials(
      shopifyOAuth.formatCredentials(credentials)
    );

    // Update or create channel credentials
    await db.channelCredentials.upsert({
      where: {
        teamId_channel: {
          teamId,
          channel: "SHOPIFY",
        },
      },
      update: {
        credentialsEncrypted: encryptedCreds,
        isActive: true,
        lastVerified: new Date(),
      },
      create: {
        teamId,
        channel: "SHOPIFY",
        credentialsEncrypted: encryptedCreds,
        isActive: true,
        lastVerified: new Date(),
      },
    });

    // Redirect to success page
    return NextResponse.redirect(
      new URL(
        `/dashboard/${teamId}/channels?success=shopify_connected`,
        request.url
      )
    );
  } catch (error) {
    console.error("Shopify OAuth callback error:", error);

    return NextResponse.json(
      {
        error: "Failed to complete Shopify authentication",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}
