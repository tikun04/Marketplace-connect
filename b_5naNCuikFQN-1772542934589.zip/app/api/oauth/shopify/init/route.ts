import { NextRequest, NextResponse } from "next/server";
import { ShopifyOAuth } from "@/lib/marketplaces/shopify-oauth";

/**
 * Initialize Shopify OAuth flow
 * POST /api/oauth/shopify/init with { teamId, shop }
 */
export async function POST(request: NextRequest) {
  try {
    const { teamId, shop } = await request.json();

    if (!teamId || !shop) {
      return NextResponse.json(
        { error: "teamId and shop are required" },
        { status: 400 }
      );
    }

    // Validate shop domain format
    const shopDomain = shop.includes(".myshopify.com") ? shop : `${shop}.myshopify.com`;

    const shopifyOAuth = new ShopifyOAuth();

    // Create state token (encode teamId in state for callback)
    const state = Buffer.from(teamId).toString("base64");

    // Generate authorization URL
    const authUrl = shopifyOAuth.generateAuthUrl(shopDomain, state);

    return NextResponse.json({ authUrl });
  } catch (error) {
    console.error("Shopify OAuth init error:", error);

    return NextResponse.json(
      {
        error: "Failed to initialize Shopify authentication",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}
