import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import crypto from "crypto";

/**
 * Verify webhook signature
 */
function verifyWebhookSignature(
  payload: string,
  signature: string,
  secret: string
): boolean {
  const hash = crypto
    .createHmac("sha256", secret)
    .update(payload)
    .digest("hex");
  return hash === signature;
}

/**
 * POST /api/webhooks
 * Handle incoming webhooks from channels
 */
export async function POST(request: NextRequest) {
  try {
    const signature = request.headers.get("x-webhook-signature");
    const source = request.headers.get("x-webhook-source");

    if (!signature || !source) {
      return NextResponse.json(
        { error: "Missing webhook headers" },
        { status: 400 }
      );
    }

    const payload = await request.text();

    // Verify signature based on source
    const secrets: Record<string, string> = {
      amazon: process.env.AMAZON_WEBHOOK_SECRET || "",
      shopify: process.env.SHOPIFY_WEBHOOK_SECRET || "",
      ebay: process.env.EBAY_WEBHOOK_SECRET || "",
    };

    const secret = secrets[source.toLowerCase()];

    if (!secret) {
      return NextResponse.json(
        { error: "Unknown webhook source" },
        { status: 400 }
      );
    }

    if (!verifyWebhookSignature(payload, signature, secret)) {
      return NextResponse.json(
        { error: "Invalid signature" },
        { status: 401 }
      );
    }

    const body = JSON.parse(payload);

    // Create webhook event record for processing
    const event = await db.webhookEvent.create({
      data: {
        source: source.toUpperCase(),
        eventType: body.eventType || body.event || "UNKNOWN",
        payload: JSON.stringify(body),
        status: "PENDING",
      },
    });

    // Return immediately - process async
    return NextResponse.json(
      { id: event.id, status: "received" },
      { status: 202 }
    );
  } catch (error) {
    console.error("Webhook processing error:", error);
    return NextResponse.json(
      { error: "Webhook processing failed" },
      { status: 500 }
    );
  }
}
