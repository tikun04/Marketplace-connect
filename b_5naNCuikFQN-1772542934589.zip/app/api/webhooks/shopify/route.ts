import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ShopifyOAuth } from "@/lib/marketplaces/shopify-oauth";
import { decryptCredentials } from "@/lib/encryption";

/**
 * Shopify webhook receiver
 * POST /api/webhooks/shopify
 * Verifies HMAC signature and processes webhook events
 */
export async function POST(request: NextRequest) {
  try {
    // Get HMAC from headers
    const hmacHeader = request.headers.get("x-shopify-hmac-sha256") || "";
    const shop = request.headers.get("x-shopify-shop-api-call-limit") || "";

    // Get raw body for signature verification
    const body = await request.text();

    // Verify webhook signature
    const shopifyOAuth = new ShopifyOAuth();
    if (!shopifyOAuth.verifyWebhookSignature(body, hmacHeader)) {
      console.warn("Shopify webhook signature verification failed");
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = JSON.parse(body);
    const topic = request.headers.get("x-shopify-topic") || "";
    const shopDomain = request.headers.get("x-shopify-shop-api-call-limit") || "";

    console.log(`[Shopify Webhook] Topic: ${topic}, Shop: ${shopDomain}`);

    // Find team with this Shopify store
    const channelCreds = await db.channelCredentials.findFirst({
      where: {
        channel: "SHOPIFY",
        credentialsEncrypted: { contains: shopDomain },
      },
      include: { team: true },
    });

    if (!channelCreds) {
      console.warn(`No team found for Shopify shop: ${shopDomain}`);
      return NextResponse.json(
        { error: "Shop not found" },
        { status: 404 }
      );
    }

    // Decrypt credentials to verify shop domain
    const creds = decryptCredentials(channelCreds.credentialsEncrypted);
    if (creds.shop !== shopDomain && !shopDomain.includes(creds.shop)) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    // Store webhook event for processing
    await db.webhookEvent.create({
      data: {
        teamId: channelCreds.teamId,
        channel: "SHOPIFY",
        eventType: topic,
        payload: body,
        processed: false,
      },
    });

    // Handle specific webhook events
    switch (topic) {
      case "products/create":
        await handleProductCreate(payload, channelCreds.teamId);
        break;
      case "products/update":
        await handleProductUpdate(payload, channelCreds.teamId);
        break;
      case "products/delete":
        await handleProductDelete(payload, channelCreds.teamId);
        break;
      case "inventory_levels/update":
        await handleInventoryUpdate(payload, channelCreds.teamId);
        break;
      default:
        console.log(`Unhandled Shopify webhook topic: ${topic}`);
    }

    // Mark as processed
    await db.webhookEvent.updateMany({
      where: {
        payload: body,
      },
      data: {
        processed: true,
        processedAt: new Date(),
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Shopify webhook error:", error);

    return NextResponse.json(
      {
        error: "Webhook processing failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}

async function handleProductCreate(payload: any, teamId: string) {
  console.log(`[Shopify] Product created: ${payload.id}`);
  // Implement product sync from Shopify to local DB if needed
}

async function handleProductUpdate(payload: any, teamId: string) {
  console.log(`[Shopify] Product updated: ${payload.id}`);
  // Implement product update sync if needed
}

async function handleProductDelete(payload: any, teamId: string) {
  console.log(`[Shopify] Product deleted: ${payload.id}`);
  // Mark listing as deleted in local DB
}

async function handleInventoryUpdate(payload: any, teamId: string) {
  console.log(`[Shopify] Inventory updated for location: ${payload.location_id}`);
  // Update inventory levels in local DB
}
