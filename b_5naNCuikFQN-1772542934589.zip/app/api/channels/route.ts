import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { db } from "@/lib/db";
import { authConfig } from "@/lib/auth";
import { channelSchema } from "@/lib/validators";
import { encryptCredentials } from "@/lib/encryption";
import { ConnectorFactory } from "@/lib/connectors";
import { ZodError } from "zod";

/**
 * GET /api/channels
 * List channels for authenticated user's team
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authConfig);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Get user's team
    const team = await db.team.findFirst({
      where: {
        members: {
          some: {
            userId: session.user.id,
          },
        },
      },
    });

    if (!team) {
      return NextResponse.json({ error: "No team found" }, { status: 403 });
    }

    const channels = await db.channel.findMany({
      where: { teamId: team.id },
      select: {
        id: true,
        name: true,
        type: true,
        status: true,
        createdAt: true,
        updatedAt: true,
        syncCount: true,
        lastSync: true,
      },
    });

    return NextResponse.json({ data: channels });
  } catch (error) {
    console.error("GET /api/channels error:", error);
    return NextResponse.json(
      { error: "Failed to fetch channels" },
      { status: 500 }
    );
  }
}

/**
 * POST /api/channels
 * Create a new channel connection
 */
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authConfig);

    if (!session?.user?.id) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await request.json();
    const validated = channelSchema.parse(body);

    // Get user's team
    const team = await db.team.findFirst({
      where: {
        members: {
          some: {
            userId: session.user.id,
            role: { in: ["OWNER", "ADMIN"] },
          },
        },
      },
    });

    if (!team) {
      return NextResponse.json(
        { error: "No admin access to team" },
        { status: 403 }
      );
    }

    // Validate connector type
    if (!ConnectorFactory.isSupported(validated.type)) {
      return NextResponse.json(
        { error: "Unsupported channel type" },
        { status: 400 }
      );
    }

    // Encrypt credentials
    const encryptedCredentials = encryptCredentials(validated.credentials);

    // Test connection
    try {
      const connector = ConnectorFactory.getConnector(
        { type: validated.type, id: "test", teamId: team.id } as any,
        validated.credentials
      );

      const isValid = await connector.authenticate();

      if (!isValid) {
        return NextResponse.json(
          { error: "Failed to authenticate with channel" },
          { status: 400 }
        );
      }
    } catch (error) {
      return NextResponse.json(
        {
          error: `Authentication error: ${error instanceof Error ? error.message : "Unknown error"}`,
        },
        { status: 400 }
      );
    }

    // Create channel
    const channel = await db.channel.create({
      data: {
        name: validated.name,
        type: validated.type,
        teamId: team.id,
        credentials: encryptedCredentials,
        status: "ACTIVE",
      },
    });

    return NextResponse.json(
      {
        id: channel.id,
        name: channel.name,
        type: channel.type,
        status: channel.status,
        createdAt: channel.createdAt,
      },
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Validation error", details: error.errors },
        { status: 400 }
      );
    }

    console.error("POST /api/channels error:", error);
    return NextResponse.json(
      { error: "Failed to create channel" },
      { status: 500 }
    );
  }
}
