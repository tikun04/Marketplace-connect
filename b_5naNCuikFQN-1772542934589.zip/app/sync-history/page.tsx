import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authConfig } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardHeader } from "@/components/dashboard-header";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

export default async function SyncHistoryPage() {
  const session = await getServerSession(authConfig);

  if (!session?.user?.id) {
    redirect("/auth/signin");
  }

  // Get user's team
  const team = await db.team.findFirst({
    where: {
      members: {
        some: {
          userId: session.user.id,
        },
      },
    },
  });

  if (!team) {
    redirect("/auth/signin");
  }

  // Get sync logs
  const syncs = await db.syncLog.findMany({
    where: {
      product: {
        teamId: team.id,
      },
    },
    include: {
      product: {
        select: {
          id: true,
          title: true,
          sku: true,
        },
      },
      channel: {
        select: {
          id: true,
          name: true,
          type: true,
        },
      },
    },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  const stats = {
    total: syncs.length,
    successful: syncs.filter((s) => s.status === "SUCCESS").length,
    failed: syncs.filter((s) => s.status === "FAILED").length,
  };

  return (
    <div className="space-y-8">
      <DashboardHeader
        title="Sync History"
        description="View all product synchronization operations"
      />

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4">
          <p className="text-sm text-muted-foreground">Total Syncs</p>
          <p className="text-2xl font-bold mt-2">{stats.total}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-muted-foreground">Successful</p>
          <p className="text-2xl font-bold text-green-600 mt-2">
            {stats.successful}
          </p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-muted-foreground">Failed</p>
          <p className="text-2xl font-bold text-red-600 mt-2">{stats.failed}</p>
        </Card>
      </div>

      {/* Sync Logs Table */}
      {syncs.length === 0 ? (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">No sync history yet</p>
        </Card>
      ) : (
        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted">
                <TableHead>Product</TableHead>
                <TableHead>Channel</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Message</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {syncs.map((sync) => (
                <TableRow key={sync.id}>
                  <TableCell>
                    <div>
                      <p className="font-medium">{sync.product.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {sync.product.sku}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <p className="font-medium">{sync.channel.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {sync.channel.type}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        sync.status === "SUCCESS" ? "default" : "destructive"
                      }
                    >
                      {sync.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground max-w-xs truncate">
                    {sync.message}
                  </TableCell>
                  <TableCell className="text-sm">
                    {new Date(sync.createdAt).toLocaleDateString()} at{" "}
                    {new Date(sync.createdAt).toLocaleTimeString()}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
