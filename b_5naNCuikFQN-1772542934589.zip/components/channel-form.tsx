"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

const CHANNEL_CONFIGS = {
  AMAZON: {
    name: "Amazon Seller Central",
    icon: "🔶",
    fields: [
      { name: "clientId", label: "Client ID", type: "text", required: true },
      {
        name: "clientSecret",
        label: "Client Secret",
        type: "password",
        required: true,
      },
      {
        name: "refreshToken",
        label: "Refresh Token",
        type: "password",
        required: true,
      },
    ],
    description: "Connect your Amazon Seller Central account",
  },
  SHOPIFY: {
    name: "Shopify Store",
    icon: "🛍️",
    fields: [
      { name: "shop", label: "Shop Domain", type: "text", placeholder: "myshop.myshopify.com", required: true },
      {
        name: "accessToken",
        label: "Access Token",
        type: "password",
        required: true,
      },
    ],
    description: "Connect your Shopify store",
  },
  EBAY: {
    name: "eBay Seller Central",
    icon: "📱",
    fields: [
      { name: "clientId", label: "Client ID", type: "text", required: true },
      {
        name: "clientSecret",
        label: "Client Secret",
        type: "password",
        required: true,
      },
      {
        name: "refreshToken",
        label: "Refresh Token",
        type: "password",
        required: true,
      },
    ],
    description: "Connect your eBay seller account",
  },
};

interface ChannelFormProps {
  onSuccess?: () => void;
}

export function ChannelForm({ onSuccess }: ChannelFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [channelType, setChannelType] = useState<string>("");
  const [channelName, setChannelName] = useState("");
  const [credentials, setCredentials] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const config = CHANNEL_CONFIGS[channelType as keyof typeof CHANNEL_CONFIGS];

  const handleCredentialChange = (field: string, value: string) => {
    setCredentials((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      if (!channelType) {
        throw new Error("Please select a channel type");
      }

      if (!channelName) {
        throw new Error("Please enter a channel name");
      }

      const response = await fetch("/api/channels", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: channelName,
          type: channelType,
          credentials,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Failed to connect channel");
      }

      toast({
        title: "Channel connected",
        description: `${config?.name} has been connected successfully`,
      });

      if (onSuccess) {
        onSuccess();
      } else {
        router.push("/channels");
        router.refresh();
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown error";
      setError(message);
      toast({
        title: "Connection failed",
        description: message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
      {/* Channel Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Select Channel</CardTitle>
          <CardDescription>Choose which marketplace to connect</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="channel">Channel Type</Label>
            <Select value={channelType} onValueChange={setChannelType}>
              <SelectTrigger id="channel">
                <SelectValue placeholder="Select a channel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="AMAZON">
                  🔶 Amazon Seller Central
                </SelectItem>
                <SelectItem value="SHOPIFY">🛍️ Shopify Store</SelectItem>
                <SelectItem value="EBAY">📱 eBay Seller Central</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {config && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{config.description}</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Channel Details */}
      {config && (
        <Card>
          <CardHeader>
            <CardTitle>{config.name}</CardTitle>
            <CardDescription>Configure your connection credentials</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="channelName">Connection Name</Label>
              <Input
                id="channelName"
                type="text"
                placeholder={`My ${config.name}`}
                value={channelName}
                onChange={(e) => setChannelName(e.target.value)}
                disabled={isLoading}
                required
              />
              <p className="text-sm text-muted-foreground">
                A friendly name to identify this channel connection
              </p>
            </div>

            <div className="border-t pt-4 space-y-4">
              {config.fields.map((field) => (
                <div key={field.name} className="space-y-2">
                  <Label htmlFor={field.name}>
                    {field.label}
                    {field.required && <span className="text-red-500 ml-1">*</span>}
                  </Label>
                  <Input
                    id={field.name}
                    type={field.type}
                    placeholder={field.placeholder}
                    value={credentials[field.name] || ""}
                    onChange={(e) =>
                      handleCredentialChange(field.name, e.target.value)
                    }
                    disabled={isLoading}
                    required={field.required}
                  />
                </div>
              ))}
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Actions */}
      {config && (
        <div className="flex gap-2">
          <Button type="submit" disabled={isLoading} className="flex-1">
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Connect Channel
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => router.back()}
            disabled={isLoading}
          >
            Cancel
          </Button>
        </div>
      )}
    </form>
  );
}
