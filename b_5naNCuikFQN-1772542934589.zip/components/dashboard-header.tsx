import { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

interface DashboardHeaderProps {
  title: string;
  description?: string;
  action?: {
    label: string;
    href?: string;
    onClick?: () => void;
  };
  children?: ReactNode;
}

export function DashboardHeader({
  title,
  description,
  action,
  children,
}: DashboardHeaderProps) {
  return (
    <div className="space-y-4 mb-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">{title}</h1>
          {description && (
            <p className="mt-2 text-base text-muted-foreground">{description}</p>
          )}
        </div>
        {action && (
          <>
            {action.href ? (
              <Link href={action.href}>
                <Button>{action.label}</Button>
              </Link>
            ) : (
              <Button onClick={action.onClick}>{action.label}</Button>
            )}
          </>
        )}
      </div>
      {children}
    </div>
  );
}
