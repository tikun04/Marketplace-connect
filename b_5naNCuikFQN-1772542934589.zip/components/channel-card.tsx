import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ConnectorFactory } from "@/lib/connectors";
import { Channel } from "@prisma/client";
import Link from "next/link";

interface ChannelCardProps {
  channel: {
    id: string;
    name: string;
    type: string;
    status: string;
    syncCount?: number;
    lastSync?: Date;
  };
}

export function ChannelCard({ channel }: ChannelCardProps) {
  const connectorName = ConnectorFactory.getConnectorName(channel.type);
  const icon = ConnectorFactory.getConnectorIcon(channel.type);

  const statusColors: Record<string, string> = {
    ACTIVE: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
    INACTIVE: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300",
    FAILED: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="text-3xl">{icon}</div>
            <div>
              <CardTitle className="text-lg">{channel.name}</CardTitle>
              <CardDescription>{connectorName}</CardDescription>
            </div>
          </div>
          <Badge className={statusColors[channel.status] || statusColors.INACTIVE}>
            {channel.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Products Synced</p>
            <p className="text-2xl font-bold">{channel.syncCount || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Last Sync</p>
            <p className="text-sm font-medium">
              {channel.lastSync
                ? new Date(channel.lastSync).toLocaleDateString()
                : "Never"}
            </p>
          </div>
        </div>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" size="sm" asChild>
            <Link href={`/channels/${channel.id}`}>View Details</Link>
          </Button>
          <Button variant="outline" size="sm" asChild>
            <Link href={`/channels/${channel.id}/settings`}>Settings</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
