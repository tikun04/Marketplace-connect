"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface Channel {
  id: string;
  name: string;
  type: string;
  status: string;
}

interface ProductSyncDialogProps {
  productId: string;
  productTitle: string;
  channels: Channel[];
  onSyncComplete?: () => void;
}

export function ProductSyncDialog({
  productId,
  productTitle,
  channels,
  onSyncComplete,
}: ProductSyncDialogProps) {
  const [open, setOpen] = useState(false);
  const [selectedChannels, setSelectedChannels] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const activeChannels = channels.filter((c) => c.status === "ACTIVE");

  const handleSync = async () => {
    if (selectedChannels.length === 0) {
      toast({
        title: "No channels selected",
        description: "Please select at least one channel to sync to.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch(`/api/products/${productId}/sync`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ channelIds: selectedChannels }),
      });

      if (!response.ok) {
        throw new Error("Sync request failed");
      }

      const data = await response.json();

      const successCount = data.results.filter(
        (r: any) => r.success
      ).length;
      const failureCount = data.results.length - successCount;

      toast({
        title: "Sync completed",
        description: `${successCount} successful, ${failureCount} failed`,
      });

      setOpen(false);
      setSelectedChannels([]);
      onSyncComplete?.();
    } catch (error) {
      toast({
        title: "Sync failed",
        description:
          error instanceof Error ? error.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          Sync Product
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Sync "{productTitle}" to Channels</DialogTitle>
          <DialogDescription>
            Select which channels you want to sync this product to.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {activeChannels.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No active channels available. Please connect a channel first.
            </p>
          ) : (
            <div className="space-y-3">
              {activeChannels.map((channel) => (
                <div key={channel.id} className="flex items-center space-x-3">
                  <Checkbox
                    id={channel.id}
                    checked={selectedChannels.includes(channel.id)}
                    onCheckedChange={(checked) => {
                      setSelectedChannels((prev) =>
                        checked
                          ? [...prev, channel.id]
                          : prev.filter((id) => id !== channel.id)
                      );
                    }}
                  />
                  <label
                    htmlFor={channel.id}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    {channel.name} ({channel.type})
                  </label>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSync} disabled={isLoading}>
            {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Sync Now
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
